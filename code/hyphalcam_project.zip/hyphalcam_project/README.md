# HyphalCam V2 control software

Replacement for `HyphalCam_V6.py`, written against the V2 board (Chapter 2 pin map and LED channel map).
Python 3.11+ (Raspberry Pi OS Bookworm or newer).

| Module | What it does |
| --- | --- |
| `stepper.py` | DRV8825 microstepping, hardware-timed pulses (pigpio DMA), trapezoid accel ramps, soft limits, position saved across power cycles |
| `leds.py` | PCA9685 I2C driver (register level) + `LedController`: named LEDs, level 0..1, thread-safe, `describe()` for UI sliders |
| `camera.py` | Picamera2 wrapper: ISO, exposure, AWB / colour gains, brightness, contrast, saturation, sharpness, focus, noise reduction; JPEG / DNG |
| `scan.py` | Move, light, capture, upload. One photo per *preset* (LED mix + camera settings) per position |
| `sim.py` | Fake pigpio / I2C / camera so everything runs on a laptop: `--sim` |
| `cli.py` | `python -m hyphalcam ...` |

## Pi setup

```bash
sudo raspi-config nonint do_i2c 0                      # enable I2C
sudo apt install pigpio python3-pigpio python3-smbus2 python3-picamera2
sudo systemctl enable --now pigpiod                    # the stepper needs this daemon
```
If `apt` cannot find `pigpio` on your Pi OS release, tell me and I will swap in a different pulse backend.
`rclone` must already be configured as in V6. Run the code with the system Python (or a venv created with `--system-site-packages`) so `picamera2` is visible.

Before first power-up of the board, apply the Chapter 2 fixes that matter to this code:
R4/R5 to 0 ohm (otherwise I2C will not ACK), MOSFET drain/source swap (otherwise LEDs cannot be turned off), PD controller for 12 V.

## First run, in this order

```bash
cp hyphalcam.example.toml hyphalcam.toml
python -m hyphalcam --sim scan --photos 2 --no-upload     # whole stack on fake hardware, no Pi needed

python -m hyphalcam led list
python -m hyphalcam led test                              # lights each LED in turn: checks the channel map
python -m hyphalcam led set white=1 uv_365=0.5

python -m hyphalcam camera shot --out t.jpg --iso 100 --exposure-us 8000

python -m hyphalcam motor info
python -m hyphalcam calibrate                             # teach it home and the tube length (see Calibration)
python -m hyphalcam motor jog 0.5 --rpm 60                # direction wrong? set forward_dir_level = 0
python -m hyphalcam motor jog -0.5 --rpm 60

python -m hyphalcam --config hyphalcam.toml scan
```

## Speed

Microstepping itself does not raise top speed: finer steps need more pulses per second for the same RPM.
It makes motion smoother and quieter, and reduces resonance. The speed gain comes from (1) hardware-timed pulses
(V6 was capped near 500 steps/s by `sleep(0.001)`, about 150 RPM at full step) and (2) the acceleration ramp.

Time for one full 17 in pass (computed by the profile code):

| Setting | Steps/s | Pass |
| --- | --- | --- |
| V6: 150 RPM, full step | 500 | 108 s |
| 240 RPM, 1/16 (default) | 12,800 | 69 s |
| 480 RPM, 1/8 | 12,800 | 35 s |
| 600 RPM, 1/4 | 8,000 | 28 s |

How far you can go is set by the motor and board, not the software: 12 V supply voltage, the DRV8825 Vref current limit,
and the screw (a long thin screw can whip at some speed). Raise `max_rpm` in steps of about 60, and if it stalls
lower `accel_rpm_per_s` first, then drop to a coarser microstep. Try a move with
`motor jog 5 --rpm 360 --accel 400 --microstep 8` before changing the config.

The DRV8825 STEP pulse minimum is 1.9 us; the code uses 10 us. `tick_us` must match pigpiod's sample rate (default 5 us).

## LEDs and the future UI

`LedController` is the API the UI should call; nothing in it prints or blocks:

```python
leds = LedController.from_config(cfg.leds)
leds.set("green", 0.4)                  # slider
leds.set_many({"white": 1, "nir_a": 1}) # one I2C burst
leds.describe()                         # [{name, label, channel, min, max, step, value, color, ...}] -> JSON
leds.state()                            # {name: level}
with leds.illuminate({"uv_365": 1.0}):  # always off afterwards
    ...
```
Level 1.0 uses the PCA9685 full-on bit: no PWM, so no banding. Levels between 0 and 1 are PWM (about 1.5 kHz),
which can band with short exposures; for repeatable images prefer full-on and change exposure/ISO instead.
Channel edges are staggered so the LEDs do not all switch on together. `max_total_level` in the config caps the
sum of all LEDs if you need to stay inside the power budget. `gamma = 2.2` makes slider feel perceptual.

The camera side is the same: `camera.apply(iso=200, exposure_us=12000)`, `camera.describe()` gives slider ranges
read from the sensor, `camera.current()` gives live exposure/gain.

## Scan behaviour

* Positions are `tube_length_in * k / N`, k = 1..N, same as V6; the carriage returns to 0 at the end.
* Each preset: LEDs off, camera settings applied and confirmed from sensor metadata, LEDs on, `settle_s`, discard
  frames, capture, LEDs off. A `manifest.json` records position, LEDs and the exposure/gain the sensor actually used.
* Upload uses the V6 folder layout. **Local files are deleted only if rclone succeeds.** V6 deleted them regardless.
* Ctrl-C or SIGTERM stops the motor, turns LEDs off, uploads what was captured.
* Position is tracked in software (see "Knowing where the camera is" below) and saved to `~/.hyphalcam_state.json`.
  If power dies mid-move the scan refuses to start until the position is re-referenced (`motor home` with a
  switch, or jog to the home end and `motor zero` without one, or pass `--force`). A scan always begins at 0.
* Staging is `~/hyphalcam_staging`, not `/tmp`: `/tmp` is RAM on current Pi OS and DNG files are about 25 MB each.

## Calibration: home and tube length

Run this once after the carriage and lead screw are assembled (and again if you change the screw or the tube).
Use PyCharm's **Terminal** tab: arrow keys do not work in the Run window, where you type a letter then Enter.

```
python -m hyphalcam calibrate
```
1. Jog the carriage to the **top** (the home end) with the arrow keys and press **H**.
2. Jog it **down** to the far end and press **E** (end calibration).

| Key | Does |
| --- | --- |
| Down arrow / S | move away from home |
| Up arrow / W | move toward home |
| + / - | bigger / smaller step (0.005 to 5 in, starts at 0.5) |
| H | mark home here (position 0) |
| E | end calibration, save |
| Q | quit, nothing saved |

You jog with the keyboard, not by hand, because the Pi can only measure distance from the steps it sends the motor.
There are no soft limits while calibrating, so use small steps near the ends and stop before the carriage touches
anything; a 40 in safety limit (`calibration_max_travel_in`) stops a runaway.

On **E** you can type the length you measured with a tape measure (or press Enter to accept the Pi's number).
A tape measurement also corrects the screw pitch, so inches on screen match real inches along the whole tube.
The result goes to `~/.hyphalcam_calibration.json` and is used automatically by `scan`, `motor` and everything
else, overriding `tube_length_in` and `inches_per_rev` from your config file. Home is saved as position 0,
and a home switch, if you add one, re-finds it on every scan.

## Knowing where the camera is

The carriage position is counted from the steps sent to the motor ("dead reckoning"). It is exact as long as the
motor never skips a step and nothing moves the carriage while power is off. Nothing on the V2 board can check that,
so there are two levels:

**Without a switch (works today).** `motor zero` at the home end declares that spot 0. After that `motor where`
(or `stepper.position_info()`) reports inches, mm, microsteps, fraction of the tube, and how the zero was set:

```
python -m hyphalcam motor where
inches 4.25 | mm 107.95 | fraction_of_tube 0.25 | reference manual | uncertain False
```
`reference` is `none` (never zeroed, assumed at home), `manual` (you ran `motor zero`) or `switch` (homed).
Every image in `manifest.json` records `position_in`, `position_mm` and `position_reference`.
If power dies or a move is interrupted, `uncertain` is set and the scan refuses to run.

**With a home switch (recommended, needs a wire).** A limit switch at the home end lets the software find its
own zero, so skipped steps or a hand-moved carriage never accumulate:

1. Wire a normally-open switch between a free GPIO and GND at the home (0) end. GPIO17 (header pin 11) is unused
   on the V2 board and sits next to GND on pin 9. The Pi's internal pull-up is used, so no resistor is needed.
   Use 3.3 V logic only.
2. Set `home_pin = 17` in `[stepper]` (see `hyphalcam.example.toml`).
3. `python -m hyphalcam motor home`. It drives toward home at `homing_fast_rpm`, stops the instant the switch
   trips, backs off, approaches again slowly at `homing_slow_rpm`, then sets position 0 `home_clearance_in`
   (0.05 in) from the trigger so normal moves never press the switch.
4. From then on `scan` homes automatically at the start (`home_before_scan = true`), and also recovers by itself
   after a power loss instead of refusing.

If homing reports "not found", check the wiring and `home_pin`; "still pressed" means the polarity is
wrong (`home_active_level`) or the switch is stuck. Homing ignores the soft limits, so make sure the switch
really is at the home end, and the carriage stops at the switch, not a hard stop behind it: the switch lever
must tolerate the small overtravel while the motor stops (a fraction of a millimetre at the default speeds).

There is no switch at the far end, so the 17 in soft limit relies on the position being right.

## Not verified on hardware

Tests (`python -m unittest discover -s tests`, 69 tests) run against fakes, so these need checking on the Pi
(homing included: that the switch reads correctly and the motor stops cleanly when it trips):
that pigpio accepts the wave chains on your OS release, the DIR polarity, the motor's real top speed,
the PCA9685 address (default 0x40) and that its OE pin is tied low, and Picamera2 control behaviour on your camera.
If `wave_chain` is rejected, run `python -m hyphalcam -v motor jog 1 --rpm 60` and send me the error.
