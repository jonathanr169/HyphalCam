"""HyphalCam V2 control software.

Layout
------
config.py   dataclasses + TOML loading for every tunable value
stepper.py  DRV8825 driver: microstepping, hardware-timed (DMA) pulses, accel ramps
leds.py     PCA9685 I2C driver + named LED controller (UI-ready API)
camera.py   Picamera2 wrapper: ISO / exposure / white balance / focus / capture
scan.py     the scan routine (move -> light -> capture -> upload)
sim.py      fake hardware so everything runs on a laptop
cli.py      `python -m hyphalcam ...`
"""

__version__ = "0.1.0"
