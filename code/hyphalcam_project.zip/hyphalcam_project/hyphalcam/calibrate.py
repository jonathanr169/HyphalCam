"""Interactive calibration: teach the Pi where home is and how long the tube is.

    python -m hyphalcam calibrate        (run it in a real terminal, e.g. PyCharm's Terminal tab)

  1. Jog the carriage to the TOP (the home end) and press H.
  2. Jog it DOWN to the far end and press E (end calibration).

The Pi can only measure distance from the steps it sends the motor, so you jog with the keyboard
rather than pushing the carriage by hand. At the end you can type a length measured with a tape
measure; the screw pitch is then corrected so inches on screen match inches on the tube.

The result is saved to `stepper.calibration_file` and used by every later command.
Soft limits are off while calibrating, because the tube length is exactly what is unknown, so
jog the last bit slowly (small steps) and stop before the carriage touches the end.
"""
from __future__ import annotations

import json
import logging
import os
import sys
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable

from .stepper import FINEST, Stepper

log = logging.getLogger(__name__)

STEP_SIZES_IN = [0.005, 0.02, 0.1, 0.5, 2.0, 5.0]
DEFAULT_STEP_INDEX = 3            # 0.5 in
MIN_LENGTH_IN = 0.5

INSTRUCTIONS = """\
HyphalCam calibration
  1. Jog the carriage to the TOP (home end), then press H.
  2. Jog it DOWN to the far end, then press E to end calibration.

  Down arrow / S   move away from home        Up arrow / W   move toward home
  +  /  -          bigger / smaller step
  H  mark home here      E  end calibration      Q  quit without saving
Go slowly near the ends: there are no limits while calibrating.
"""


class CalibrationError(RuntimeError):
    """A recoverable problem: the message is shown and calibration carries on."""


@dataclass
class CalibrationResult:
    tube_length_in: float
    inches_per_rev: float
    length_fine: int              # tube length in 1/32 steps: independent of microstepping
    corrected_with_tape: bool
    calibrated_at: str


class CalibrationSession:
    """The logic behind the keys; no terminal needed, so it can be tested."""

    def __init__(self, stepper: Stepper, step_sizes: list[float] | None = None):
        self.st = stepper
        self.step_sizes = list(step_sizes or STEP_SIZES_IN)
        self.step_index = min(DEFAULT_STEP_INDEX, len(self.step_sizes) - 1)
        self.home_marked = False
        self._ref_fine = stepper._pos_fine      # where we started: the travel limit counts from here

    @property
    def step_in(self) -> float:
        return self.step_sizes[self.step_index]

    def bigger(self) -> None:
        self.step_index = min(self.step_index + 1, len(self.step_sizes) - 1)

    def smaller(self) -> None:
        self.step_index = max(self.step_index - 1, 0)

    def jog(self, direction: int) -> None:
        """direction +1 = away from home (down), -1 = toward home (up)."""
        c = self.st.cfg
        delta = direction * self.step_in
        new_fine = self.st._pos_fine + round(delta / c.inches_per_rev * c.steps_per_rev * FINEST)
        travelled = abs(new_fine - self._ref_fine) / FINEST / c.steps_per_rev * c.inches_per_rev
        if travelled - 0.001 > c.calibration_max_travel_in:      # 1 mil of slack for step rounding
            raise CalibrationError(f"That would be {travelled:.1f} in from the start, past the "
                                   f"{c.calibration_max_travel_in:g} in safety limit "
                                   "(stepper.calibration_max_travel_in).")
        self.st.move_inches(delta, max_rpm=c.calibration_rpm, check_limits=False)
        if self.st.last_move_aborted:
            raise CalibrationError("Move interrupted: the position is an estimate. "
                                   "Mark home again if you are at the top.")

    def mark_home(self) -> None:
        self.st.set_zero()
        self._ref_fine = 0
        self.home_marked = True

    def length_so_far(self) -> float:
        if not self.home_marked:
            raise CalibrationError("Mark home first: jog to the top and press H.")
        length = self.st.position_in
        if length < 0:
            raise CalibrationError(f"The carriage is {-length:.2f} in ABOVE the home mark. Jog down to the "
                                   "far end of the tube before pressing E (or press H to move home).")
        if length < MIN_LENGTH_IN:
            raise CalibrationError(f"The carriage is only {length:.2f} in from home. Jog down to the "
                                   "far end of the tube before pressing E.")
        return length

    def finish(self, measured_in: float | None = None) -> CalibrationResult:
        """Apply the result: tube length = distance from home to here (or the tape measurement)."""
        length = self.length_so_far()
        pitch = self.st.cfg.inches_per_rev
        if measured_in is not None:
            if not MIN_LENGTH_IN <= measured_in <= 5 * length:
                raise CalibrationError(f"{measured_in:g} in doesn't look right: the carriage travelled "
                                       f"{length:.2f} in. Check the number, or press Enter to skip.")
            pitch = pitch * measured_in / length
            length = measured_in
        length, pitch = round(length, 6), round(pitch, 8)        # exactly what gets saved and applied
        self.st.set_geometry(tube_length_in=length, inches_per_rev=pitch)
        self.st._max_fine = max(self.st._max_fine, self.st._pos_fine)   # the end we stand at is reachable
        return CalibrationResult(length, pitch, self.st._pos_fine,
                                 measured_in is not None, datetime.now().isoformat(timespec="seconds"))

    def status(self) -> str:
        return (f"\r  position {self.st.position_in:8.3f} in   step {self.step_in:6.3f} in   "
                f"home: {'set' if self.home_marked else 'NOT set'}   ")


def save_calibration(path: str | Path, result: CalibrationResult) -> Path:
    p = Path(os.path.expanduser(str(path)))
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(asdict(result), indent=2))
    os.replace(tmp, p)
    return p


def run_interactive(stepper: Stepper, read_key: Callable[[], str], ask: Callable[[str], str],
                    out: Callable[[str], None]) -> CalibrationResult | None:
    """The keyboard loop. Returns the result, or None if the user quit."""
    session = CalibrationSession(stepper)
    out(INSTRUCTIONS)
    try:
        while True:
            out(session.status())
            try:
                key = read_key()
            except KeyboardInterrupt:
                key = "q"
            try:
                if key in ("down", "s"):
                    session.jog(+1)
                elif key in ("up", "w"):
                    session.jog(-1)
                elif key == "+" or key == "=":
                    session.bigger()
                elif key == "-":
                    session.smaller()
                elif key == "h":
                    session.mark_home()
                    out("\n  Home marked here (position 0). Now jog DOWN to the far end, then press E.\n")
                elif key == "e":
                    length = session.length_so_far()
                    out(f"\n  The carriage is {length:.3f} in from home (using the screw pitch in the config).\n")
                    typed = ask("  Length measured with a tape, in inches (Enter to accept): ").strip()
                    measured = float(typed) if typed else None
                    result = session.finish(measured)
                    path = save_calibration(stepper.cfg.calibration_file, result)
                    out(f"\n  Saved: tube length {result.tube_length_in:.3f} in, "
                        f"screw pitch {result.inches_per_rev:.5f} in/rev -> {path}\n")
                    if not ask("  Return the carriage to home now? [Y/n] ").strip().lower().startswith("n"):
                        stepper.move_to_inches(0.0)
                    return result
                elif key == "q":
                    out("\n  Calibration cancelled, nothing saved.\n")
                    return None
            except CalibrationError as exc:
                out(f"\n  {exc}\n")
            except ValueError:
                out("\n  That wasn't a number. Press E to try again.\n")
    finally:
        stepper.disable()


# ----------------------------------------------------------------- terminal helpers
class Keyboard:
    """Single-key input for the calibration screen.

    In a real terminal it stays in no-echo, one-key-at-a-time mode for the whole session, so keys
    pressed while the carriage is moving don't print junk and queue up quietly. Prompts that need a
    typed line (`ask`) switch back to normal mode and drop any queued keys first.
    Without a terminal (a pipe, or an IDE run window) it reads a letter then Enter instead.
    """

    def __init__(self):
        self.tty = sys.stdin.isatty()
        self._fd = sys.stdin.fileno() if self.tty else None
        self._old = None

    def __enter__(self):
        if self.tty:
            import termios
            import tty
            self._old = termios.tcgetattr(self._fd)
            tty.setcbreak(self._fd)
        return self

    def __exit__(self, *exc):
        if self.tty and self._old is not None:
            import termios
            termios.tcsetattr(self._fd, termios.TCSADRAIN, self._old)
        return False

    def read_key(self) -> str:
        """'up', 'down' or the lowercase character; 'q' if input ends."""
        if not self.tty:
            ch = sys.stdin.read(1)
            while ch in ("\n", "\r", " "):
                ch = sys.stdin.read(1)
            return ch.lower() if ch else "q"
        import select
        ch = os.read(self._fd, 1).decode(errors="ignore")
        if ch == "\x1b":                                   # arrow keys arrive as ESC [ A / ESC [ B
            seq = ""
            while len(seq) < 2 and select.select([self._fd], [], [], 0.05)[0]:
                seq += os.read(self._fd, 1).decode(errors="ignore")
            return {"[A": "up", "[B": "down"}.get(seq, "esc")
        return ch.lower()

    def ask(self, prompt: str) -> str:
        if not self.tty:
            return input(prompt)
        import termios
        import tty
        termios.tcflush(self._fd, termios.TCIFLUSH)        # forget arrow presses queued during a move
        termios.tcsetattr(self._fd, termios.TCSADRAIN, self._old)
        try:
            return input(prompt)
        finally:
            tty.setcbreak(self._fd)


def write(text: str) -> None:
    sys.stdout.write(text)
    sys.stdout.flush()
