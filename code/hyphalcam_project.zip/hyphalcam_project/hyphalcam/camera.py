"""Picamera2 wrapper with the controls you will want sliders for.

Setting names (used in the config, in scan presets, and later by the UI):

  iso                  100 = analogue gain 1.0 (libcamera convention; the sensor has no real ISO)
  analogue_gain        raw gain, alternative to iso
  exposure_us          shutter time in microseconds
  auto_exposure        True = camera chooses exposure and gain
  awb                  auto white balance on/off
  colour_gains         (red_gain, blue_gain); turns AWB off
  brightness           -1..1      contrast, saturation 0..32      sharpness 0..16
  lens_position        dioptres (0 = infinity). Only if the lens has a focus motor
  noise_reduction      "off" | "fast" | "high_quality" | "minimal"

Setting exposure_us or iso without auto_exposure switches auto exposure off.
Values outside what the sensor supports are clamped, with a warning.
"""
from __future__ import annotations

import logging
import threading
import time
from pathlib import Path
from typing import Any

from .config import CameraConfig

log = logging.getLogger(__name__)

# high-level name -> libcamera control name, for plain numeric controls
_SIMPLE = {"brightness": "Brightness", "contrast": "Contrast",
           "saturation": "Saturation", "sharpness": "Sharpness",
           "analogue_gain": "AnalogueGain", "lens_position": "LensPosition"}
_VALID = set(_SIMPLE) | {"iso", "exposure_us", "auto_exposure", "awb", "colour_gains", "noise_reduction"}
_NR_MODES = {"off": 0, "fast": 1, "high_quality": 2, "minimal": 3}
_KEEP_METADATA = ("ExposureTime", "AnalogueGain", "DigitalGain", "ColourGains", "ColourTemperature",
                  "Lux", "SensorTemperature", "LensPosition", "FocusFoM", "FrameDuration", "SensorTimestamp")


def translate_settings(settings: dict[str, Any], limits: dict[str, tuple], default_fd=None) -> dict[str, Any]:
    """High-level settings -> libcamera control dict. Pure function, no hardware needed.

    `limits` is Picamera2.camera_controls: {name: (min, max, default)}.
    """
    s = dict(settings)
    bad = set(s) - _VALID
    if bad:
        raise ValueError(f"unknown camera setting(s) {sorted(bad)}; valid: {sorted(_VALID)}")

    out: dict[str, Any] = {}

    def clamp(ctrl: str, value):
        lim = limits.get(ctrl)
        if lim is None:
            return value
        lo, hi = lim[0], lim[1]
        if lo is not None and value < lo or hi is not None and value > hi:
            log.warning("%s=%s outside supported range %s..%s, clamping", ctrl, value, lo, hi)
            value = min(max(value, lo), hi)
        return value

    iso, gain = s.pop("iso", None), s.pop("analogue_gain", None)
    if iso is not None and gain is not None:
        raise ValueError("give iso or analogue_gain, not both")
    if iso is not None:
        gain = iso / 100.0
    exposure = s.pop("exposure_us", None)
    auto = s.pop("auto_exposure", None)

    if auto is True:
        out["AeEnable"] = True
        if exposure is not None or gain is not None:
            log.warning("exposure/iso ignored because auto_exposure is on")
        if default_fd is not None:
            out["FrameDurationLimits"] = default_fd
    elif auto is False or exposure is not None or gain is not None:
        out["AeEnable"] = False
        if exposure is not None:
            exposure = int(clamp("ExposureTime", int(exposure)))
            out["ExposureTime"] = exposure
            # a frame must last at least as long as the exposure
            fd = max(exposure, 33333)
            out["FrameDurationLimits"] = (fd, fd)
        if gain is not None:
            out["AnalogueGain"] = float(clamp("AnalogueGain", float(gain)))

    if "awb" in s:
        out["AwbEnable"] = bool(s.pop("awb"))
    if "colour_gains" in s:
        r, b = s.pop("colour_gains")
        out["AwbEnable"] = False
        out["ColourGains"] = (float(r), float(b))
    if "noise_reduction" in s:
        mode = s.pop("noise_reduction")
        if mode not in _NR_MODES:
            raise ValueError(f"noise_reduction must be one of {sorted(_NR_MODES)}")
        out["NoiseReductionMode"] = mode          # converted to the libcamera enum in apply()
    for key, ctrl in _SIMPLE.items():
        if key in s:
            if ctrl not in limits and limits:
                log.warning("camera has no %s control, skipping %s", ctrl, key)
                s.pop(key)
                continue
            out[ctrl] = float(clamp(ctrl, float(s.pop(key))))
    return out


class CameraController:
    def __init__(self, cfg: CameraConfig, picam2=None):
        self.cfg = cfg
        if picam2 is None:
            # noinspection PyUnresolvedReferences
            from picamera2 import Picamera2        # noqa: PLC0415  (lazy: Pi only)
            picam2 = Picamera2(cfg.camera_num)
        self.picam2 = picam2
        self.settings: dict[str, Any] = {}
        self._lock = threading.RLock()
        self._started = False
        self._default_fd = None

    # ---- lifecycle
    def start(self) -> None:
        c, cam = self.cfg, self.picam2
        main = {"size": (c.width, c.height)}
        if c.format in ("dng", "both"):
            config = cam.create_still_configuration(main=main, raw={"size": cam.sensor_resolution})
        else:
            config = cam.create_still_configuration(main=main)
        cam.configure(config)
        cam.options["quality"] = c.jpeg_quality
        cam.start()
        self._started = True
        fd = cam.camera_controls.get("FrameDurationLimits")
        if fd:                                        # remember the default so auto exposure can restore it
            d = fd[2]
            self._default_fd = tuple(d) if isinstance(d, (tuple, list)) else (int(d), int(d))
        self.apply(**c.settings)
        time.sleep(0.5)

    def stop(self) -> None:
        if self._started:
            self.picam2.stop()
            self._started = False

    def close(self) -> None:
        self.stop()
        if hasattr(self.picam2, "close"):
            self.picam2.close()

    # ---- settings
    def apply(self, wait: bool = True, **settings) -> dict[str, Any]:
        """Apply settings, then (optionally) wait until the sensor reports them in use."""
        with self._lock:
            controls = translate_settings(settings, self.picam2.camera_controls, self._default_fd)
            nr = controls.get("NoiseReductionMode")
            if nr is not None:
                controls["NoiseReductionMode"] = self._enum("draft.NoiseReductionModeEnum", nr)
            if "LensPosition" in controls:
                controls["AfMode"] = self._enum("AfModeEnum", "manual")
            self.settings.update(settings)
            if controls:
                self.picam2.set_controls(controls)
                if wait:
                    self.wait_applied(controls)
            return controls

    @staticmethod
    def _enum(path: str, value):
        """libcamera enum if the libcamera module exists, else the plain integer."""
        try:
            # noinspection PyUnresolvedReferences
            from libcamera import controls as lc          # noqa: PLC0415  (Pi only)
            enum = lc
            for part in path.split("."):
                enum = getattr(enum, part)
            if path.startswith("draft.Noise"):
                return {"off": enum.Off, "fast": enum.Fast, "high_quality": enum.HighQuality,
                        "minimal": enum.Minimal}[value]
            return enum.Manual
        except ImportError:
            return _NR_MODES.get(value, 0) if path.startswith("draft.Noise") else 0

    def wait_applied(self, controls: dict[str, Any], timeout: float | None = None) -> bool:
        """New exposure/gain take a few frames to reach the sensor. Poll metadata until they do."""
        timeout = self.cfg.apply_timeout_s if timeout is None else timeout
        want_exp, want_gain = controls.get("ExposureTime"), controls.get("AnalogueGain")
        if controls.get("AeEnable") or (want_exp is None and want_gain is None):
            self.flush(self.cfg.ae_settle_frames if controls.get("AeEnable") else self.cfg.flush_frames)
            return True
        deadline = time.monotonic() + max(timeout, (want_exp or 0) / 1e6 * 4)
        while time.monotonic() < deadline:
            md = self.picam2.capture_metadata()
            ok_exp = want_exp is None or abs(md.get("ExposureTime", 0) - want_exp) <= max(50, 0.03 * want_exp)
            ok_gain = want_gain is None or abs(md.get("AnalogueGain", 0) - want_gain) <= 0.03 * want_gain
            if ok_exp and ok_gain:
                return True
        log.warning("camera did not report requested exposure/gain within %.1fs", timeout)
        return False

    def flush(self, frames: int | None = None) -> None:
        """Discard frames so the next capture reflects the current light and settings."""
        for _ in range(self.cfg.flush_frames if frames is None else frames):
            self.picam2.capture_metadata()

    def current(self) -> dict[str, Any]:
        """What the sensor is doing right now (from live metadata)."""
        md = self.picam2.capture_metadata()
        return {k: md[k] for k in _KEEP_METADATA if k in md}

    def describe(self) -> dict[str, dict]:
        """Ranges for UI sliders, in the high-level setting names."""
        lim = self.picam2.camera_controls

        def rng(ctrl, scale=1.0):
            if ctrl not in lim:
                return None
            lo, hi, default = lim[ctrl][:3]
            return {"min": lo * scale, "max": hi * scale, "default": default * scale}

        info = {"exposure_us": rng("ExposureTime"), "iso": rng("AnalogueGain", 100.0)}
        for key, ctrl in _SIMPLE.items():
            if key != "analogue_gain":
                info[key] = rng(ctrl)
        info = {k: v for k, v in info.items() if v is not None}
        for k, v in info.items():
            v["value"] = self.settings.get(k)
        return info

    # ---- capture
    def capture(self, stem: str | Path) -> tuple[list[Path], dict[str, Any]]:
        """Save one frame as <stem>.jpg and/or <stem>.dng. Returns (files, metadata)."""
        stem = str(stem)
        files: list[Path] = []
        with self._lock:
            request = self.picam2.capture_request()
            try:
                if self.cfg.format in ("jpeg", "both"):
                    request.save("main", stem + ".jpg")
                    files.append(Path(stem + ".jpg"))
                if self.cfg.format in ("dng", "both"):
                    request.save_dng(stem + ".dng")
                    files.append(Path(stem + ".dng"))
                md = request.get_metadata()
            finally:
                request.release()
        return files, {k: _plain(md[k]) for k in _KEEP_METADATA if k in md}


def _plain(v):
    return list(v) if isinstance(v, tuple) else v
