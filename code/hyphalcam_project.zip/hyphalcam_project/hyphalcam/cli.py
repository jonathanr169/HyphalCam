"""Command line: python -m hyphalcam [--config FILE] [--sim] <command>

  calibrate                    jog to home and to the far end; saves the tube length
  scan                         run the full scan (V6 replacement)
  led list | set NAME=LEVEL... | off | test
  motor info | where | home | jog INCHES | goto INCHES | steps N | zero
  camera info | shot --out FILE [--iso N] [--exposure-us N] ...
"""
from __future__ import annotations

import argparse
import logging
import signal
import sys
import time
from pathlib import Path

from .config import Config, load_config

log = logging.getLogger("hyphalcam")


# ---- hardware factories (the only place that decides real vs simulated)
def make_stepper(cfg: Config, sim: bool):
    from .stepper import Stepper
    if sim:
        from .sim import FakePigpio
        cfg.stepper.state_file = "~/.hyphalcam_state_sim.json"   # keep sim runs out of the real position file
        pg = FakePigpio(time_scale=50)
        st = Stepper(cfg.stepper, pg)
        if cfg.stepper.home_pin is not None:                      # simulated carriage + home switch
            c = cfg.stepper
            to_fine = lambda inches: round(inches / c.inches_per_rev * c.steps_per_rev * 32)
            pg.last.attach_carriage(dir_pin=c.dir_pin, forward_level=c.forward_dir_level,
                                    unit_fn=lambda: 32 // st.microstep, start_fine=st._pos_fine,
                                    switch_pin=c.home_pin, switch_fine=-to_fine(c.home_clearance_in),
                                    active_level=c.home_active_level)
        return st
    return Stepper(cfg.stepper)


def make_leds(cfg: Config, sim: bool):
    from .leds import PCA9685, LedController
    if sim:
        from .sim import FakeI2C
        lc = cfg.leds
        pca = PCA9685(i2c=FakeI2C(), address=lc.address, pwm_hz=lc.pwm_hz)
        return LedController.from_config(lc, pca)
    return LedController.from_config(cfg.leds)


def make_camera(cfg: Config, sim: bool):
    from .camera import CameraController
    if sim:
        from .sim import FakePicamera2
        return CameraController(cfg.camera, FakePicamera2())
    return CameraController(cfg.camera)


# ---- commands
def cmd_scan(args, cfg, sim):
    from .scan import ScanRunner
    if args.photos:
        cfg.scan.num_positions = args.photos
    stepper, leds, camera = make_stepper(cfg, sim), make_leds(cfg, sim), make_camera(cfg, sim)
    camera.start()
    runner = ScanRunner(cfg, stepper, leds, camera)
    for sig in (signal.SIGINT, signal.SIGTERM):      # Ctrl-C or Witty Pi shutdown: stop cleanly
        signal.signal(sig, lambda *_: runner.cancel())
    try:
        res = runner.run(force=args.force, upload=False if args.no_upload else None)
    finally:
        camera.close()
        leds.close()
        stepper.close()
    print(f"{'Completed' if res.completed else 'Stopped early'}: {len(res.files)} files, "
          f"{'uploaded' if res.uploaded else 'not uploaded'} ({res.folder if not res.uploaded else res.remote_folder})")
    return 0 if res.completed else 1


def cmd_led(args, cfg, sim):
    leds = make_leds(cfg, sim)
    try:
        if args.action == "list":
            for d in leds.describe():
                print(f"ch{d['channel']:>2}  {d['name']:<11} {d['label']}")
        elif args.action == "set":
            levels = {}
            for item in args.items:
                name, _, value = item.partition("=")
                levels[name] = float(value)
            leds.set_many(levels)
            print(leds.state())
            input("LEDs on. Press Enter to turn them off... ") if not sim else None
        elif args.action == "off":
            leds.all_off()
        elif args.action == "test":
            for d in leds.describe():                  # wiring check: one LED at a time
                print(f"{d['name']} (channel {d['channel']})")
                leds.set(d["name"], 0.3)
                time.sleep(0.6)
                leds.all_off()
    finally:
        leds.close()
    return 0


def cmd_motor(args, cfg, sim):
    st = make_stepper(cfg, sim)
    try:
        if args.action == "info":
            c = cfg.stepper
            print(f"microstep 1/{st.microstep}   position {st.position_in:.4f} in"
                  f"{'   (UNCERTAIN)' if st.position_uncertain else ''}")
            print(f"resolution {c.inches_per_rev / (c.steps_per_rev * st.microstep) * 25400:.2f} um/step")
            hz = st.rpm_to_hz(c.max_rpm)
            print(f"max {c.max_rpm:g} rpm = {hz:,.0f} steps/s = {c.max_rpm / 60 * c.inches_per_rev:.3f} in/s "
                  f"(cap {c.max_step_rate_hz:,} steps/s)")
        elif args.action == "where":
            for key, value in st.position_info().items():
                print(f"{key:<17} {value}")
        elif args.action == "home":
            signal.signal(signal.SIGINT, lambda *_: st.stop())
            st.home()
            print(f"Homed. Position {st.position_in:.4f} in")
        elif args.action == "zero":
            st.set_zero()
            print("Position set to 0 (manual reference)")
        else:
            if args.microstep:
                st.set_microstep(args.microstep)
            kw = {k: v for k, v in (("max_rpm", args.rpm), ("accel_rpm_per_s", args.accel)) if v}
            signal.signal(signal.SIGINT, lambda *_: st.stop())
            t0 = time.monotonic()
            if args.action == "jog":
                done = st.move_inches(args.value, **kw)
            elif args.action == "goto":
                done = st.move_to_inches(args.value, **kw)
            else:
                done = st.move_steps(int(args.value), **kw)
            print(f"moved {done} microsteps in {time.monotonic() - t0:.2f}s, now at {st.position_in:.4f} in")
    finally:
        st.close()
    return 0


def cmd_calibrate(args, cfg, sim):
    from .calibrate import Keyboard, run_interactive, write
    if not sys.stdin.isatty():
        print("Note: not a real terminal, so type a letter then Enter for each key "
              "(run it from PyCharm's Terminal tab for arrow keys).", file=sys.stderr)
    st = make_stepper(cfg, sim)
    signal.signal(signal.SIGINT, lambda *_: st.stop())     # Ctrl-C stops a move; Q quits
    try:
        with Keyboard() as kb:
            result = run_interactive(st, kb.read_key, kb.ask, write)
    finally:
        st.close()
    return 0 if result else 1


def cmd_camera(args, cfg, sim):
    cam = make_camera(cfg, sim)
    cam.start()
    try:
        if args.action == "info":
            for k, v in cam.describe().items():
                print(f"{k:<14} {v}")
        else:
            settings = {k: v for k, v in (("iso", args.iso), ("exposure_us", args.exposure_us),
                                          ("brightness", args.brightness), ("contrast", args.contrast),
                                          ("saturation", args.saturation), ("sharpness", args.sharpness),
                                          ("lens_position", args.lens_position)) if v is not None}
            if args.auto:
                settings["auto_exposure"] = True
            if settings:
                cam.apply(**settings)
            files, md = cam.capture(Path(args.out).with_suffix(""))
            print(", ".join(map(str, files)), md)
    finally:
        cam.close()
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="hyphalcam")
    p.add_argument("--config", help="TOML config file")
    p.add_argument("--sim", action="store_true", help="use fake hardware (no Pi needed)")
    p.add_argument("-v", "--verbose", action="store_true")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("scan")
    s.add_argument("--photos", type=int, help="positions per scan (overrides config)")
    s.add_argument("--no-upload", action="store_true")
    s.add_argument("--force", action="store_true", help="scan even if the carriage position is uncertain")
    s.set_defaults(fn=cmd_scan)

    s = sub.add_parser("led")
    s.add_argument("action", choices=["list", "set", "off", "test"])
    s.add_argument("items", nargs="*", help="NAME=LEVEL (0..1), e.g. white=1 uv_365=0.5")
    s.set_defaults(fn=cmd_led)

    s = sub.add_parser("motor")
    s.add_argument("action", choices=["info", "where", "home", "zero", "jog", "goto", "steps"])
    s.add_argument("value", nargs="?", type=float, help="inches (jog/goto) or microsteps (steps)")
    s.add_argument("--rpm", type=float, help="cruise rpm for this move")
    s.add_argument("--accel", type=float, help="acceleration in rpm/s for this move")
    s.add_argument("--microstep", type=int, choices=[1, 2, 4, 8, 16, 32])
    s.set_defaults(fn=cmd_motor)

    s = sub.add_parser("calibrate", help="teach the Pi where home is and how long the tube is")
    s.set_defaults(fn=cmd_calibrate)

    s = sub.add_parser("camera")
    s.add_argument("action", choices=["info", "shot"])
    s.add_argument("--out", default="shot.jpg")
    s.add_argument("--auto", action="store_true", help="auto exposure")
    s.add_argument("--iso", type=float)
    s.add_argument("--exposure-us", type=int)
    s.add_argument("--brightness", type=float)
    s.add_argument("--contrast", type=float)
    s.add_argument("--saturation", type=float)
    s.add_argument("--sharpness", type=float)
    s.add_argument("--lens-position", type=float)
    s.set_defaults(fn=cmd_camera)
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(asctime)s %(message)s")
    if args.cmd == "motor" and args.action in ("jog", "goto", "steps") and args.value is None:
        print("motor", args.action, "needs a value", file=sys.stderr)
        return 2
    cfg = load_config(args.config)
    if args.sim:                                                   # never touch the real calibration
        cfg.stepper.calibration_file = "~/.hyphalcam_calibration_sim.json"
    from .config import apply_calibration
    apply_calibration(cfg)
    from .scan import PositionUncertain
    from .stepper import LimitError, MotionError
    try:
        return args.fn(args, cfg, args.sim)
    except (MotionError, LimitError, PositionUncertain) as exc:     # expected failures: message, no traceback
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
