"""All tunable values live here. Defaults match the HyphalCam V2 schematic
(Chapter 2 of the documentation: Pi pin map and LED channel map)."""
from __future__ import annotations

import tomllib
from dataclasses import dataclass, field, fields, is_dataclass
from pathlib import Path
from typing import Any


@dataclass
class StepperConfig:
    # Pi GPIO (BCM numbering) -> DRV8825, from the Chapter 2 pin map
    step_pin: int = 21
    dir_pin: int = 20
    enable_pin: int = 19          # active low
    m0_pin: int = 11
    m1_pin: int = 12
    m2_pin: int = 13

    steps_per_rev: int = 200      # 1.8 deg motor (42BYGH60)
    microstep: int = 16           # 1, 2, 4, 8, 16 or 32 (DRV8825)

    # Motion profile. Speeds are motor shaft RPM, independent of microstep.
    start_rpm: float = 20.0       # speed the motor can start at with no ramp
    max_rpm: float = 240.0        # cruise speed. Raise gradually (see README)
    accel_rpm_per_s: float = 600.0
    ramp_levels: int = 32         # speed steps used to approximate each ramp

    # Pulse generation (pigpio DMA). tick_us must equal pigpiod's sample rate (default 5).
    step_pulse_us: int = 10       # DRV8825 needs >= 1.9 us
    tick_us: int = 5
    max_step_rate_hz: int = 50000

    # Mechanics
    inches_per_rev: float = 0.063     # lead screw travel per turn (V6: TRAVEL_PER_TURN)
    tube_length_in: float = 17.0      # soft limit: allowed travel is 0..tube_length_in
    forward_dir_level: int = 1        # DIR level that moves away from home (V6: CW = 1)

    # Written by `python -m hyphalcam calibrate`; overrides tube_length_in and inches_per_rev when present.
    calibration_file: str = "~/.hyphalcam_calibration.json"
    calibration_rpm: float = 60.0         # jog speed while calibrating
    calibration_max_travel_in: float = 40.0   # refuse to jog further than this from the reference point

    # Optional home limit switch at the 0 end. None = no switch (position is dead-reckoned only).
    # Wire a normally-open switch between this GPIO and GND; the Pi's internal pull-up is used.
    home_pin: int | None = None
    home_pull_up: bool = True
    home_active_level: int = 0        # pin level when the switch is pressed (0 for switch-to-GND)
    homing_fast_rpm: float = 120.0    # first approach; the motor stops dead when the switch trips
    homing_slow_rpm: float = 20.0     # final approach: this sets the zero repeatability
    homing_backoff_in: float = 0.05   # how far to back off the switch before the slow approach
    home_clearance_in: float = 0.05   # position 0 sits this far from the trigger point (no overtravel)

    hold_between_moves: bool = False  # keep coils energised between moves (hotter, stiffer)
    enable_settle_s: float = 0.002
    state_file: str = "~/.hyphalcam_state.json"  # remembers position across power cycles


@dataclass
class LedChannel:
    name: str
    channel: int
    label: str = ""
    wavelength_nm: float | None = None
    color: str = "#ffffff"            # swatch colour for the future UI
    max_level: float = 1.0            # hard cap for this LED (0..1)


@dataclass
class LedConfig:
    i2c_bus: int = 1
    address: int = 0x40
    pwm_hz: float = 1500.0            # PCA9685 max is ~1526 Hz
    gamma: float = 1.0                # 1.0 = light output proportional to slider
    stagger: bool = True              # offset channel edges to avoid current spikes
    totem_pole: bool = True
    invert: bool = False
    max_total_level: float | None = None   # optional cap on the sum of all LED levels
    channels: list[LedChannel] | None = None  # None -> leds.DEFAULT_LEDS


@dataclass
class CameraConfig:
    camera_num: int = 0
    width: int = 4056
    height: int = 3040
    format: str = "jpeg"              # "jpeg", "dng" or "both"
    jpeg_quality: int = 95
    # Default settings applied at start-up (same names as Preset.camera)
    settings: dict[str, Any] = field(default_factory=lambda: {"auto_exposure": True})
    flush_frames: int = 2             # frames discarded after LEDs/controls change
    ae_settle_frames: int = 10        # frames discarded when auto exposure is on
    apply_timeout_s: float = 3.0


@dataclass
class Preset:
    """One illumination + camera setting. The scan takes one photo per preset per position."""
    name: str
    leds: dict[str, float] = field(default_factory=dict)
    camera: dict[str, Any] = field(default_factory=dict)
    settle_s: float = 0.3             # wait after LEDs switch on, before capture


@dataclass
class UploadConfig:
    enabled: bool = True
    rclone_remote: str = ""           # "" -> f"guzmanpi{pi_number}_gdrive"
    base_folder: str = "rpicamfiles"
    retries: int = 3
    retry_wait_s: float = 5.0


@dataclass
class ScanConfig:
    pi_number: int = 1
    num_positions: int = 10
    settle_after_move_s: float = 0.5
    post_capture_delay_s: float = 0.0     # V6 used 2.0 with the LED left on
    return_home: bool = True
    home_before_scan: bool = True         # re-reference on the home switch at the start of every scan
    staging_dir: str = "~/hyphalcam_staging"   # on disk, NOT /tmp (tmpfs on new Pi OS)
    presets: list[Preset] = field(default_factory=lambda: [Preset("white", {"white": 1.0})])
    upload: UploadConfig = field(default_factory=UploadConfig)


@dataclass
class Config:
    stepper: StepperConfig = field(default_factory=StepperConfig)
    leds: LedConfig = field(default_factory=LedConfig)
    camera: CameraConfig = field(default_factory=CameraConfig)
    scan: ScanConfig = field(default_factory=ScanConfig)


def _build(cls, data: dict):
    """Recursively build a dataclass from a dict, rejecting unknown keys (catches typos)."""
    known = {f.name: f for f in fields(cls)}
    unknown = set(data) - set(known)
    if unknown:
        raise ValueError(f"{cls.__name__}: unknown setting(s) {sorted(unknown)}; valid: {sorted(known)}")
    nested = {
        (Config, "stepper"): StepperConfig, (Config, "leds"): LedConfig,
        (Config, "camera"): CameraConfig, (Config, "scan"): ScanConfig,
        (ScanConfig, "upload"): UploadConfig,
    }
    kwargs = {}
    for key, val in data.items():
        if (cls, key) in nested:
            kwargs[key] = _build(nested[(cls, key)], val)
        elif cls is ScanConfig and key == "presets":
            # TOML: [scan.presets.white] -> Preset(name="white", ...)
            kwargs[key] = [_build(Preset, {"name": n, **p}) for n, p in val.items()]
        elif cls is LedConfig and key == "channels":
            kwargs[key] = [_build(LedChannel, c) for c in val]
        else:
            kwargs[key] = val
    return cls(**kwargs)


def apply_calibration(cfg: Config) -> dict | None:
    """If `calibrate` has been run, use its measured tube length and screw pitch.

    The calibration wins over the same values in the TOML file: it was measured on this machine.
    Returns the calibration data, or None if there is no (readable) calibration file.
    """
    import json
    import logging
    path = Path(cfg.stepper.calibration_file).expanduser()
    try:
        data = json.loads(path.read_text())
        length, pitch = float(data["tube_length_in"]), float(data["inches_per_rev"])
    except FileNotFoundError:
        return None
    except (ValueError, KeyError, OSError) as exc:
        logging.getLogger(__name__).warning("Ignoring unreadable calibration file %s (%s)", path, exc)
        return None
    if length <= 0 or pitch <= 0:
        logging.getLogger(__name__).warning("Ignoring calibration file %s: non-positive values", path)
        return None
    cfg.stepper.tube_length_in, cfg.stepper.inches_per_rev = length, pitch
    logging.getLogger(__name__).info("Using calibrated tube length %.3f in (%s)", length, path)
    return data


def load_config(path: str | Path | None) -> Config:
    """Load a TOML file; no path -> all defaults."""
    if path is None:
        return Config()
    with open(Path(path).expanduser(), "rb") as fh:
        return _build(Config, tomllib.load(fh))
