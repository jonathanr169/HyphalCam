"""LED control: PCA9685 16-channel PWM driver over I2C, plus a named-LED layer.

Hardware path (Chapter 2): Pi GPIO2/GPIO3 (I2C1) -> PCA9685 -> 220 ohm -> AO3400A gate
-> LED + series resistor. A high output turns the LED on. (This assumes the Chapter 2
fix where the LED cathode goes to the MOSFET drain.)

Two layers:
  PCA9685        register-level protocol, knows nothing about LEDs
  LedController  named LEDs with levels 0..1; this is the API a UI should call
"""
from __future__ import annotations

import logging
import threading
import time
from contextlib import contextmanager
from dataclasses import asdict

from .config import LedChannel, LedConfig

log = logging.getLogger(__name__)

# ---- PCA9685 registers (datasheet section 7.3)
MODE1, MODE2 = 0x00, 0x01
LED0_ON_L = 0x06                    # 4 registers per channel: ON_L, ON_H, OFF_L, OFF_H
ALL_LED_ON_L = 0xFA
PRESCALE = 0xFE
# MODE1 bits
RESTART, AI, SLEEP, ALLCALL = 0x80, 0x20, 0x10, 0x01
# MODE2 bits
INVRT, OUTDRV = 0x10, 0x04
FULL = 0x10                          # bit 4 of ON_H = fully on, of OFF_H = fully off
STEPS = 4096


def prescale_for(hz: float, osc_hz: int = 25_000_000) -> int:
    """PRE_SCALE register value for a PWM frequency (allowed range 3..255)."""
    return max(3, min(255, round(osc_hz / (STEPS * hz)) - 1))


def channel_registers(counts: int, phase: int = 0) -> list[int]:
    """[ON_L, ON_H, OFF_L, OFF_H] for `counts` of 4096 on-time starting at `phase`."""
    counts = max(0, min(STEPS, int(counts)))
    if counts == 0:
        return [0, 0, 0, FULL]       # fully off: no PWM edges at all
    if counts == STEPS:
        return [0, FULL, 0, 0]       # fully on: no PWM edges, so no flicker in photos
    on = phase % STEPS
    off = (on + counts) % STEPS
    return [on & 0xFF, on >> 8, off & 0xFF, off >> 8]


# UPDATE TEST: this line was added by Claude on 2026-11-24 to confirm edits reach PyCharm.
class PCA9685:
    def __init__(self, bus: int = 1, address: int = 0x40, *, i2c=None, pwm_hz: float = 1500.0,
                 totem_pole: bool = True, invert: bool = False, osc_hz: int = 25_000_000):
        if i2c is None:
            # noinspection PyUnresolvedReferences
            from smbus2 import SMBus        # noqa: PLC0415  (lazy: Pi only, not installed on a laptop)
            i2c = SMBus(bus)
        self._i2c = i2c
        self.address = address
        self.osc_hz = osc_hz
        self.actual_hz = 0.0
        self._lock = threading.RLock()
        self._init(pwm_hz, totem_pole, invert)

    def _write(self, reg: int, value: int) -> None:
        self._i2c.write_byte_data(self.address, reg, value)

    def _read(self, reg: int) -> int:
        return self._i2c.read_byte_data(self.address, reg)

    def _init(self, pwm_hz: float, totem_pole: bool, invert: bool) -> None:
        # No general-call software reset on purpose: the Witty Pi shares this I2C bus.
        with self._lock:
            old = self._read(MODE1) & ~RESTART
            # sleep so PRE_SCALE can be written; AI on so block writes auto-increment
            self._write(MODE1, (old | SLEEP | AI) & ~ALLCALL)
            self.all_off()                                          # nothing lights while we configure
            self.set_pwm_freq(pwm_hz, _asleep=True)
            self._write(MODE2, (OUTDRV if totem_pole else 0) | (INVRT if invert else 0))
            self._write(MODE1, AI)                                  # wake, auto-increment, no all-call
            time.sleep(0.001)                                       # oscillator start-up (500 us)
            self._write(MODE1, AI | RESTART)

    def set_pwm_freq(self, hz: float, *, _asleep: bool = False) -> float:
        with self._lock:
            ps = prescale_for(hz, self.osc_hz)
            if not _asleep:
                mode = self._read(MODE1)
                self._write(MODE1, (mode & ~RESTART) | SLEEP)
            self._write(PRESCALE, ps)
            if not _asleep:
                self._write(MODE1, mode & ~RESTART & ~SLEEP)
                time.sleep(0.001)
                self._write(MODE1, (mode & ~SLEEP) | RESTART)
            self.actual_hz = self.osc_hz / (STEPS * (ps + 1))
            return self.actual_hz

    def set_channel(self, channel: int, counts: int, phase: int = 0) -> None:
        """One channel, one I2C transaction (counts 0..4096)."""
        self._check(channel)
        with self._lock:
            self._i2c.write_i2c_block_data(self.address, LED0_ON_L + 4 * channel,
                                           channel_registers(counts, phase))

    def set_all(self, counts: list[int], phases: list[int] | None = None) -> None:
        """All 16 channels in two 32-byte block writes (SMBus block limit)."""
        if len(counts) != 16:
            raise ValueError("need 16 channel values")
        phases = phases or [0] * 16
        data: list[int] = []
        for c, p in zip(counts, phases):
            data += channel_registers(c, p)
        with self._lock:
            for start in (0, 8):
                self._i2c.write_i2c_block_data(self.address, LED0_ON_L + 4 * start,
                                               data[4 * start: 4 * (start + 8)])

    def all_off(self) -> None:
        with self._lock:
            self._i2c.write_i2c_block_data(self.address, ALL_LED_ON_L, [0, 0, 0, FULL])

    def sleep(self) -> None:
        """Oscillator off. Outputs hold their registers but stop switching."""
        with self._lock:
            self.all_off()
            self._write(MODE1, (self._read(MODE1) & ~RESTART) | SLEEP)

    @staticmethod
    def _check(channel: int) -> None:
        if not 0 <= channel <= 15:
            raise ValueError("PCA9685 channel must be 0..15")

    def close(self) -> None:
        try:
            self.all_off()
        finally:
            if hasattr(self._i2c, "close"):
                self._i2c.close()


# Channel map from Chapter 2, section 2.2 (designators in labels)
DEFAULT_LEDS: list[LedChannel] = [
    LedChannel("uv_365",     15, "UV 365 nm (D2)",     365.0, "#7a3cff"),
    LedChannel("violet",     14, "Violet (D3)",        None,  "#9b30ff"),
    LedChannel("royal_blue", 13, "Royal blue (D4)",    None,  "#2447ff"),
    LedChannel("green",      12, "Green (D5)",         None,  "#22c55e"),
    LedChannel("pc_lime",    11, "PC lime (D6)",       None,  "#c8f000"),
    LedChannel("amber",      10, "Amber (D7)",         None,  "#ffb000"),
    LedChannel("red",         9, "Red (D10)",          None,  "#ff2a2a"),
    LedChannel("white",       8, "White (D9)",         None,  "#f5f5f5"),
    LedChannel("nir_a",       7, "NIR (D8)",           None,  "#8b1a1a"),
    LedChannel("nir_b",       6, "NIR (D11)",          None,  "#6b1313"),
]


class LedController:
    """Named LEDs with brightness 0.0 .. 1.0. Thread-safe, so a UI thread and a scan can share it.

    Level 1.0 uses the PCA9685 "full on" bit (no PWM at all), which is flicker-free for
    short exposures. Levels between 0 and 1 are PWM at `pwm_hz`; with exposures shorter
    than a few PWM periods expect banding, so prefer full-on and adjust exposure / ISO.
    """

    def __init__(self, pca: PCA9685, channels: list[LedChannel] | None = None, *,
                 gamma: float = 1.0, stagger: bool = True, max_total_level: float | None = None):
        self.pca = pca
        self.specs = {c.name: c for c in (channels or DEFAULT_LEDS)}
        chans = [c.channel for c in self.specs.values()]
        if len(set(chans)) != len(chans):
            raise ValueError("two LEDs share a PCA9685 channel")
        self.gamma = gamma
        self.stagger = stagger
        self.max_total_level = max_total_level
        self._levels = {name: 0.0 for name in self.specs}
        self._lock = threading.RLock()
        self._write_all()

    @classmethod
    def from_config(cls, cfg: LedConfig, pca: PCA9685 | None = None) -> "LedController":
        pca = pca or PCA9685(cfg.i2c_bus, cfg.address, pwm_hz=cfg.pwm_hz,
                             totem_pole=cfg.totem_pole, invert=cfg.invert)
        return cls(pca, cfg.channels, gamma=cfg.gamma, stagger=cfg.stagger,
                   max_total_level=cfg.max_total_level)

    # ---- control
    def set(self, name: str, level: float) -> None:
        self.set_many({name: level})

    def set_many(self, levels: dict[str, float]) -> None:
        """Change several LEDs in one I2C burst. Unlisted LEDs keep their level."""
        with self._lock:
            new = dict(self._levels)
            for name, level in levels.items():
                new[name] = self._clamp(name, level)
            new = self._limit_total(new)
            self._levels = new
            self._write_all()

    def all_off(self) -> None:
        with self._lock:
            self._levels = {n: 0.0 for n in self.specs}
            self.pca.all_off()

    @contextmanager
    def illuminate(self, levels: dict[str, float]):
        """`with leds.illuminate({"uv_365": 1.0}): capture()`; everything is off afterwards."""
        with self._lock:
            self.all_off()
            self.set_many(levels)
            try:
                yield
            finally:
                self.all_off()

    # ---- inspection (feeds a UI)
    def state(self) -> dict[str, float]:
        with self._lock:
            return dict(self._levels)

    def describe(self) -> list[dict]:
        """One dict per LED: everything a slider needs (range, step, label, colour, value)."""
        with self._lock:
            return [{**asdict(s), "min": 0.0, "max": s.max_level, "step": 1 / 255,
                     "value": self._levels[s.name]} for s in self.specs.values()]

    # ---- internals
    def _clamp(self, name: str, level: float) -> float:
        if name not in self.specs:
            raise KeyError(f"unknown LED {name!r}; available: {sorted(self.specs)}")
        return max(0.0, min(float(level), self.specs[name].max_level))

    def _limit_total(self, levels: dict[str, float]) -> dict[str, float]:
        cap = self.max_total_level
        total = sum(levels.values())
        if cap is not None and total > cap:
            log.warning("LED levels sum to %.2f, scaling to the %.2f limit", total, cap)
            return {n: v * cap / total for n, v in levels.items()}
        return levels

    def _counts(self, level: float) -> int:
        return round((level ** self.gamma) * STEPS)

    def _write_all(self) -> None:
        counts, phases = [0] * 16, [0] * 16
        for name, spec in self.specs.items():
            counts[spec.channel] = self._counts(self._levels[name])
            if self.stagger:
                phases[spec.channel] = spec.channel * (STEPS // 16)
        self.pca.set_all(counts, phases)

    def close(self) -> None:
        self.all_off()
        self.pca.close()
