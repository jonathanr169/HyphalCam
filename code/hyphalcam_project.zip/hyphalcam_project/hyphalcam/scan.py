"""The scan routine: for each position, move, then take one photo per illumination preset.

Same flow and folder layout as HyphalCam_V6.py, with these differences:
  * a "preset" = LED levels + camera settings, so one position can give white, UV and NIR images
  * photos are deleted locally only after rclone reports success (V6 deleted them regardless)
  * a failed or cancelled run still uploads what it captured
  * LEDs are always switched off and the motor released, even on error
"""
from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from .camera import CameraController
from .config import Config
from .leds import LedController
from .stepper import Stepper

log = logging.getLogger(__name__)


@dataclass
class ScanResult:
    folder: Path
    remote_folder: str
    files: list[Path] = field(default_factory=list)
    uploaded: bool = False
    completed: bool = False


class PositionUncertain(RuntimeError):
    pass


def upload_with_rclone(src: Path, remote: str, folder: str, retries: int = 3, wait_s: float = 5.0) -> bool:
    if not shutil.which("rclone"):
        log.error("rclone not found in PATH; files stay in %s", src)
        return False
    for attempt in range(1, retries + 1):
        result = subprocess.run(["rclone", "copy", str(src), f"{remote}:{folder}"],
                                capture_output=True, text=True)
        if result.returncode == 0:
            log.info("Upload successful")
            return True
        log.warning("Upload attempt %d/%d failed (code %d): %s", attempt, retries,
                    result.returncode, result.stderr.strip()[-300:])
        if attempt < retries:
            time.sleep(wait_s)
    return False


class ScanRunner:
    def __init__(self, cfg: Config, stepper: Stepper, leds: LedController, camera: CameraController,
                 uploader=upload_with_rclone):
        self.cfg, self.stepper, self.leds, self.camera = cfg, stepper, leds, camera
        self.uploader = uploader
        self._cancel = threading.Event()

    def cancel(self) -> None:
        """Safe to call from a signal handler or UI thread."""
        self._cancel.set()
        self.stepper.stop()

    def run(self, *, force: bool = False, upload: bool | None = None, positions: int | None = None) -> ScanResult:
        sc = self.cfg.scan
        n = positions or sc.num_positions
        st = self.stepper
        if st.has_home_switch and (sc.home_before_scan or (st.position_uncertain and not force)):
            st.home()                                    # re-reference: removes any accumulated drift
        elif st.position_uncertain and not force:
            raise PositionUncertain("Carriage position is unknown. Jog it to the home end, run "
                                    "`motor zero`, or pass --force. (A home switch would make "
                                    "this automatic: see stepper.home_pin.)")
        elif st.reference == "none":
            log.warning("Carriage position was never referenced; assuming it is at the home end. "
                        "Run `motor zero` there once to record that.")
        now = datetime.now()
        run_folder = now.strftime("run_%H-%M")
        camera_folder = f"camera{sc.pi_number}"
        remote_folder = f"{sc.upload.base_folder}/{now:%Y-%m-%d}/{camera_folder}/{run_folder}"
        staging = Path(os.path.expanduser(sc.staging_dir)) / f"{now:%Y-%m-%d}_{camera_folder}_{run_folder}"
        staging.mkdir(parents=True, exist_ok=True)

        result = ScanResult(staging, remote_folder)
        manifest: list[dict] = []
        self._cancel.clear()
        tube = self.cfg.stepper.tube_length_in
        try:
            if abs(self.stepper.position_in) > 0.01:
                log.info("Moving to start (%.3f in)", self.stepper.position_in)
                self.stepper.move_to_inches(0.0)

            for i in range(n):
                if self._cancel.is_set():
                    break
                target = tube * (i + 1) / n
                log.info("Position %d/%d -> %.3f in", i + 1, n, target)
                self.stepper.move_to_inches(target)
                if self._cancel.is_set():
                    break
                time.sleep(sc.settle_after_move_s)
                for preset in sc.presets:
                    if self._cancel.is_set():
                        break
                    entry = self._take(preset, i + 1, n, staging)
                    result.files += [staging / f for f in entry["files"]]
                    manifest.append(entry)
                    if sc.post_capture_delay_s:
                        time.sleep(sc.post_capture_delay_s)

            if sc.return_home and not self._cancel.is_set():
                log.info("Returning home")
                self.stepper.move_to_inches(0.0)
            result.completed = not self._cancel.is_set()
        finally:
            self.leds.all_off()
            self.stepper.disable()
            log.info("Carriage at %.3f in", self.stepper.position_in)
            if manifest:
                (staging / "manifest.json").write_text(json.dumps(
                    {"remote_folder": remote_folder, "completed": result.completed, "images": manifest}, indent=2))
            do_upload = sc.upload.enabled if upload is None else upload
            if do_upload and manifest:
                self._upload(staging, result)
        return result

    def _take(self, preset, position: int, total: int, staging: Path) -> dict:
        self.leds.all_off()
        if preset.camera:
            self.camera.apply(**preset.camera)
        self.leds.set_many(preset.leds)
        time.sleep(preset.settle_s)
        self.camera.flush()                    # drop frames exposed before the LEDs were stable
        ts = datetime.now().strftime("%H-%M-%S")
        stem = staging / f"pos{position}_of{total}__{preset.name}__{ts}"
        files, metadata = self.camera.capture(stem)
        self.leds.all_off()
        log.info("Captured %s", ", ".join(f.name for f in files))
        return {"position": position, "position_in": round(self.stepper.position_in, 4),
                "position_mm": round(self.stepper.position_in * 25.4, 3),
                "position_reference": self.stepper.reference,
                "preset": preset.name, "leds": dict(preset.leds), "camera_settings": dict(preset.camera),
                "files": [f.name for f in files], "metadata": metadata, "time": ts}

    def _upload(self, staging: Path, result: ScanResult) -> None:
        up = self.cfg.scan.upload
        remote = up.rclone_remote or f"guzmanpi{self.cfg.scan.pi_number}_gdrive"
        ok = self.uploader(staging, remote, result.remote_folder, up.retries, up.retry_wait_s)
        result.uploaded = ok
        if ok:
            shutil.rmtree(staging, ignore_errors=True)
            log.info("Deleted local staging folder")
        else:
            log.error("Upload failed. Nothing was deleted; files are in %s", staging)
