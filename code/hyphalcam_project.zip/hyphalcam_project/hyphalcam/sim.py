"""Fake hardware: lets the whole stack run on a laptop and in tests.

FakePigpio    implements the slice of pigpio the stepper uses, including a chain
              interpreter, so tests can check the exact number of STEP pulses
FakeI2C       a 256-byte PCA9685 register file with auto-increment
FakePicamera2 enough of Picamera2 for CameraController
"""
from __future__ import annotations

import time
from collections import namedtuple
from pathlib import Path

OUTPUT = 1


def interpret_chain(chain: list[int], wave_period_us: dict[int, int]) -> tuple[int, float]:
    """Run a pigpio wave chain on paper. Returns (steps, seconds). Supports nested loops."""
    def run(i: int, stop_at_end: bool):
        steps, secs = 0, 0.0
        while i < len(chain):
            b = chain[i]
            if b != 255:                                   # plain wave id
                steps += 1
                secs += wave_period_us[b] / 1e6
                i += 1
            elif chain[i + 1] == 0:                        # loop start
                (s, t), i, count = run(i + 2, True)
                steps += s * count
                secs += t * count
            elif chain[i + 1] == 1:                        # loop end
                count = chain[i + 2] + 256 * chain[i + 3]
                return (steps, secs), i + 4, count
            else:
                raise ValueError("unsupported chain command")
        return (steps, secs), i, 1
    (steps, secs), _, _ = run(0, False)
    return steps, secs


class FakePi:
    connected = True

    def __init__(self, time_scale: float = 1.0):
        self.gpio: dict[int, int] = {}
        self.modes: dict[int, int] = {}
        self.waves: dict[int, int] = {}          # wave id -> period in us
        self._pending: list = []
        self._next_id = 0
        self.chains: list[list[int]] = []
        self.step_count = 0                      # total STEP pulses emitted by completed chains
        self.write_log: list[tuple[int, int]] = []
        self._busy_until = 0.0
        self.time_scale = time_scale
        self.true_fine = 0                       # simulated carriage position, in 1/32 steps
        self._dir = 1
        self._carriage: dict | None = None

    def attach_carriage(self, *, dir_pin, forward_level, unit_fn, start_fine=0,
                        switch_pin=None, switch_fine=0, active_level=0):
        """Simulate the carriage and a home switch. The switch reads 'pressed' while the true
        position is <= switch_fine, including part-way through a move."""
        self._carriage = dict(dir_pin=dir_pin, forward_level=forward_level, unit_fn=unit_fn,
                              switch_pin=switch_pin, switch_fine=switch_fine, active_level=active_level)
        self.true_fine = start_fine

    def _progress(self):
        if not self._busy_until:
            return 0
        frac = min(1.0, (time.monotonic() - self._t0) * self.time_scale / max(self._chain_secs, 1e-9))
        return int(self._chain_steps * frac)

    def _apply(self, steps):
        if self._carriage:
            self.true_fine += self._dir * steps * self._carriage["unit_fn"]()

    def read(self, pin):
        k = self._carriage
        if k and pin == k["switch_pin"]:
            true = self.true_fine
            if self._busy_until:
                true += self._dir * self._progress() * k["unit_fn"]()
            return k["active_level"] if true <= k["switch_fine"] else 1 - k["active_level"]
        return self.gpio.get(pin, 1)

    def set_pull_up_down(self, pin, pud): pass
    def set_mode(self, pin, mode): self.modes[pin] = mode
    def write(self, pin, level):
        self.gpio[pin] = level
        self.write_log.append((pin, level))

    def wave_clear(self): self.waves.clear(); self._pending.clear(); self._next_id = 0
    def wave_add_generic(self, pulses): self._pending += list(pulses)

    def wave_create(self):
        wid = self._next_id
        self._next_id += 1
        self.waves[wid] = sum(p.delay for p in self._pending)
        self._pending = []
        return wid

    def wave_chain(self, chain):
        self.chains.append(list(chain))
        steps, secs = interpret_chain(chain, self.waves)
        self._chain_steps, self._chain_secs = steps, secs
        if self._carriage:
            k = self._carriage
            self._dir = 1 if self.gpio.get(k["dir_pin"], 0) == k["forward_level"] else -1
        self._t0 = time.monotonic()
        self._busy_until = self._t0 + secs / self.time_scale
        return len(chain)

    def wave_tx_busy(self):
        if self._busy_until and time.monotonic() >= self._busy_until:
            self.step_count += self._chain_steps
            self._apply(self._chain_steps)
            self._busy_until = 0.0
        return self._busy_until > 0.0

    def wave_tx_stop(self):
        if self._busy_until:
            done = self._progress()
            self.step_count += done
            self._apply(done)
        self._busy_until = 0.0
    def stop(self): pass


class FakePigpio:
    """Stands in for the `pigpio` module."""
    OUTPUT = OUTPUT
    INPUT = 0
    PUD_OFF, PUD_DOWN, PUD_UP = 0, 1, 2
    pulse = namedtuple("pulse", "gpio_on gpio_off delay")

    def __init__(self, time_scale: float = 1.0):
        self._time_scale = time_scale
        self.last: FakePi | None = None

    def pi(self):
        self.last = FakePi(self._time_scale)
        return self.last


class FakeI2C:
    def __init__(self):
        self.regs = bytearray(256)
        self.writes: list[tuple[int, list[int]]] = []

    def read_byte_data(self, addr, reg): return self.regs[reg]
    def write_byte_data(self, addr, reg, val):
        self.regs[reg] = val
        self.writes.append((reg, [val]))

    def write_i2c_block_data(self, addr, reg, data):
        if len(data) > 32:
            raise ValueError("SMBus block limit is 32 bytes")
        auto_inc = self.regs[0x00] & 0x20
        if len(data) > 1 and not auto_inc:
            raise RuntimeError("block write without MODE1 auto-increment")
        for i, v in enumerate(data):
            self.regs[reg + i] = v
        if reg == 0xFA and len(data) == 4:             # ALL_LED_*: the chip loads every channel
            for ch in range(16):
                self.regs[0x06 + 4 * ch: 0x0A + 4 * ch] = bytes(data)
        self.writes.append((reg, list(data)))

    def close(self): pass


class _FakeRequest:
    def __init__(self, cam): self.cam = cam
    def save(self, name, path): Path(path).write_bytes(b"fake-jpeg")
    def save_dng(self, path): Path(path).write_bytes(b"fake-dng")
    def get_metadata(self): return dict(self.cam.metadata())
    def release(self): self.cam.released += 1


class FakePicamera2:
    sensor_resolution = (4056, 3040)

    def __init__(self):
        self.camera_controls = {
            "ExposureTime": (1, 200_000_000, 10000), "AnalogueGain": (1.0, 22.26, 1.0),
            "Brightness": (-1.0, 1.0, 0.0), "Contrast": (0.0, 32.0, 1.0),
            "Saturation": (0.0, 32.0, 1.0), "Sharpness": (0.0, 16.0, 1.0),
            "FrameDurationLimits": (33333, 1_000_000_000, 33333),
        }
        self.options: dict = {}
        self.controls: dict = {}
        self.set_calls: list[dict] = []
        self.released = 0
        self.started = False
        self._lag = 0            # frames until a new control shows up in metadata (like the real pipeline)
        self._applied = {"ExposureTime": 10000, "AnalogueGain": 1.0}

    def create_still_configuration(self, main=None, raw=None): return {"main": main, "raw": raw}
    def configure(self, config): self.config = config
    def start(self): self.started = True
    def stop(self): self.started = False
    def close(self): pass

    def set_controls(self, controls):
        self.set_calls.append(dict(controls))
        self.controls.update(controls)
        self._lag = 3

    def metadata(self):
        return self._applied

    def capture_metadata(self):
        if self._lag > 0:
            self._lag -= 1
            if self._lag == 0:
                for k in ("ExposureTime", "AnalogueGain"):
                    if k in self.controls:
                        self._applied[k] = self.controls[k]
        return dict(self._applied)

    def capture_request(self): return _FakeRequest(self)
