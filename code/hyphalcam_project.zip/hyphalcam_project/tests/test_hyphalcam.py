import json
import math
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from hyphalcam.camera import CameraController, translate_settings
from hyphalcam.config import CameraConfig, Config, LedConfig, Preset, StepperConfig, load_config
from hyphalcam.leds import (DEFAULT_LEDS, FULL, LED0_ON_L, PCA9685, PRESCALE, LedController,
                            channel_registers, prescale_for)
from hyphalcam.scan import PositionUncertain, ScanRunner
from hyphalcam.sim import FakeI2C, FakePicamera2, FakePigpio, interpret_chain
from hyphalcam.stepper import (LimitError, MotionError, Stepper, build_profile, loop_commands,
                               profile_to_chain, steps_done)

TMP = tempfile.mkdtemp()


def stepper_cfg(**kw):
    kw.setdefault("state_file", str(Path(TMP) / f"state_{time.monotonic_ns()}.json"))
    return StepperConfig(**kw)


# ----------------------------------------------------------------- profile math
class ProfileTests(unittest.TestCase):
    def check(self, total, **kw):
        args = dict(v_start=1000, v_max=12800, accel=32000, levels=32, tick_us=5, pulse_us=10)
        args.update(kw)
        prof = build_profile(total, args.pop("v_start"), args.pop("v_max"), args.pop("accel"), **args)
        self.assertEqual(sum(s.count for s in prof), total)
        return prof

    def test_counts_always_sum_to_total(self):
        for total in (1, 2, 3, 17, 100, 999, 5000, 53968, 864_000):
            self.check(total)

    def test_trapezoid_shape(self):
        prof = self.check(200_000)
        periods = [s.period_us for s in prof]
        peak = periods.index(min(periods))
        self.assertTrue(all(a >= b for a, b in zip(periods[:peak], periods[1:peak + 1])))   # speeding up
        self.assertTrue(all(a <= b for a, b in zip(periods[peak:], periods[peak + 1:])))    # slowing down
        self.assertAlmostEqual(1e6 / min(periods), 12800, delta=12800 * 0.05)

    def test_short_move_is_triangular_and_slower_than_vmax(self):
        prof = self.check(400)
        self.assertGreater(min(s.period_us for s in prof), 1e6 / 12800)

    def test_duration_close_to_analytic(self):
        total, v0, vm, a = 200_000, 1000.0, 12800.0, 32000.0
        prof = self.check(total, v_start=v0, v_max=vm, accel=a)
        ramp_t = (vm - v0) / a
        ramp_s = (vm ** 2 - v0 ** 2) / (2 * a)
        ideal = 2 * ramp_t + (total - 2 * ramp_s) / vm
        self.assertAlmostEqual(sum(s.duration_s for s in prof), ideal, delta=ideal * 0.04)

    def test_rate_cap_and_period_floor(self):
        prof = self.check(10_000, v_max=1_000_000, max_rate=50_000)
        self.assertGreaterEqual(min(s.period_us for s in prof), 20)

    def test_no_accel_is_one_segment(self):
        prof = self.check(1000, accel=0)
        self.assertEqual(len(prof), 1)

    def test_steps_done_estimate(self):
        prof = self.check(20_000)
        total_t = sum(s.duration_s for s in prof)
        self.assertEqual(steps_done(prof, 0), 0)
        self.assertEqual(steps_done(prof, total_t + 1), 20_000)
        mid = steps_done(prof, total_t / 2)
        self.assertTrue(8_000 < mid < 12_000)

    def test_chain_plays_exact_step_count_including_nested_loops(self):
        for total in (1, 7, 65535, 65536, 70_000, 864_000, 3_000_000):
            prof = self.check(total)
            wave_ids, periods = {}, {}
            for s in prof:
                wave_ids.setdefault(s.period_us, len(wave_ids))
                periods[wave_ids[s.period_us]] = s.period_us
            steps, secs = interpret_chain(profile_to_chain(prof, wave_ids), periods)
            self.assertEqual(steps, total)
            self.assertAlmostEqual(secs, sum(s.duration_s for s in prof), places=3)

    def test_loop_bytes(self):
        self.assertEqual(loop_commands(3, 1), [3])
        self.assertEqual(loop_commands(3, 300), [255, 0, 3, 255, 1, 44, 1])
        self.assertEqual(loop_commands(3, 0), [])


# ----------------------------------------------------------------- stepper
class StepperTests(unittest.TestCase):
    def make(self, scale=2000.0, **kw):
        pg = FakePigpio(time_scale=scale)
        return Stepper(stepper_cfg(**kw), pg), pg

    def test_microstep_pins(self):
        table = {1: (0, 0, 0), 2: (1, 0, 0), 4: (0, 1, 0), 8: (1, 1, 0), 16: (0, 0, 1), 32: (1, 0, 1)}
        st, pg = self.make()
        for m, (m0, m1, m2) in table.items():
            st.set_microstep(m)
            self.assertEqual((pg.last.gpio[11], pg.last.gpio[12], pg.last.gpio[13]), (m0, m1, m2), m)
        with self.assertRaises(ValueError):
            st.set_microstep(3)

    def test_move_emits_exact_steps_and_updates_position(self):
        st, pg = self.make(microstep=16)
        self.assertEqual(st.move_steps(32_000), 32_000)
        self.assertEqual(pg.last.step_count, 32_000)
        self.assertAlmostEqual(st.position_in, 32_000 / 3200 * 0.063, places=6)
        self.assertEqual(st.move_steps(-32_000), -32_000)
        self.assertAlmostEqual(st.position_in, 0.0, places=9)

    def test_direction_and_enable_sequencing(self):
        st, pg = self.make()
        st.move_steps(1600)
        log = pg.last.write_log
        self.assertIn((20, 1), log)                       # forward = DIR high
        en = [lvl for pin, lvl in log if pin == 19]
        self.assertEqual(en[-1], 1)                       # driver released at the end
        self.assertIn(0, en)                              # ...after being enabled
        st.move_steps(-1600)
        self.assertEqual([lvl for pin, lvl in pg.last.write_log if pin == 20][-1], 0)

    def test_soft_limits(self):
        st, _ = self.make()
        with self.assertRaises(LimitError):
            st.move_steps(-1)
        with self.assertRaises(LimitError):
            st.move_inches(17.5)
        self.assertEqual(st.position_in, 0.0)

    def test_position_is_kept_across_microstep_changes(self):
        st, _ = self.make(microstep=16)
        st.move_inches(1.0)
        pos = st.position_in
        st.set_microstep(4)
        self.assertAlmostEqual(st.position_in, pos)
        st.move_to_inches(0.0)
        self.assertAlmostEqual(st.position_in, 0.0, places=4)

    def test_move_to_inches_absolute(self):
        st, _ = self.make()
        st.move_to_inches(2.0)
        self.assertAlmostEqual(st.position_in, 2.0, delta=0.0001)
        st.move_to_inches(0.5)
        self.assertAlmostEqual(st.position_in, 0.5, delta=0.0001)

    def test_abort_estimates_position(self):
        st, pg = self.make(scale=1.0, microstep=4, max_rpm=60)    # real time so we can interrupt
        t = threading.Timer(0.3, st.stop)
        t.start()
        t0 = time.monotonic()
        done = st.move_steps(5000)                                # ~ 8 s if not aborted
        self.assertLess(time.monotonic() - t0, 2.0)
        self.assertTrue(st.last_move_aborted)
        self.assertTrue(0 < done < 5000)
        self.assertEqual(st._pos_fine, done * (32 // 4))

    def test_state_file_and_uncertain_flag(self):
        cfg = stepper_cfg()
        pg = FakePigpio(2000)
        st = Stepper(cfg, pg)
        st.move_inches(1.0)
        st2 = Stepper(cfg, pg)
        self.assertAlmostEqual(st2.position_in, 1.0, delta=0.0001)
        self.assertFalse(st2.position_uncertain)
        Path(cfg.state_file).write_text(json.dumps({"pos_fine": 100, "moving": True}))
        self.assertTrue(Stepper(cfg, pg).position_uncertain)
        st2.set_zero()
        self.assertFalse(Stepper(cfg, pg).position_uncertain)

    def test_cannot_start_second_move(self):
        st, _ = self.make(scale=1.0, microstep=4, max_rpm=60)
        th = threading.Thread(target=st.move_steps, args=(2000,))
        th.start()
        time.sleep(0.1)
        with self.assertRaises(Exception):
            st.move_steps(10)
        st.stop()
        th.join()


# ----------------------------------------------------------------- homing / position
def to_fine(st, inches):
    return round(inches / st.cfg.inches_per_rev * st.cfg.steps_per_rev * 32)


def attach_switch(st, pg, true_in, switch_in=0.0):
    """Simulated carriage at `true_in` (real position) with the switch tripping at `switch_in`."""
    pg.last.attach_carriage(dir_pin=st.cfg.dir_pin, forward_level=st.cfg.forward_dir_level,
                            unit_fn=lambda: 32 // st.microstep, start_fine=to_fine(st, true_in),
                            switch_pin=st.cfg.home_pin, switch_fine=to_fine(st, switch_in),
                            active_level=st.cfg.home_active_level)


class HomingTests(unittest.TestCase):
    def make(self, home_pin=17, scale=10.0, **kw):
        pg = FakePigpio(time_scale=scale)
        return Stepper(stepper_cfg(home_pin=home_pin, tube_length_in=3.0, **kw), pg), pg

    def true_in(self, st, pg):
        return pg.last.true_fine / 32 / st.cfg.steps_per_rev * st.cfg.inches_per_rev

    def test_home_corrects_drift(self):
        st, pg = self.make()
        attach_switch(st, pg, true_in=2.0)
        st._pos_fine = to_fine(st, 2.3)               # software believes 2.3 in: 0.3 in of drift
        st.position_uncertain = True
        st.home()
        self.assertEqual(st.reference, "switch")
        self.assertFalse(st.position_uncertain)
        self.assertAlmostEqual(st.position_in, 0.0, delta=0.0005)
        self.assertAlmostEqual(self.true_in(st, pg), 0.05, delta=0.01)   # real carriage: clearance off the switch
        self.assertFalse(st.home_switch_pressed())
        self.assertEqual(pg.last.gpio[19], 1)                            # driver released afterwards

    def test_home_when_already_on_switch(self):
        st, pg = self.make()
        attach_switch(st, pg, true_in=0.0)
        self.assertTrue(st.home_switch_pressed())
        st.home()
        self.assertAlmostEqual(self.true_in(st, pg), 0.05, delta=0.01)
        self.assertEqual(st.reference, "switch")

    def test_home_persists_reference(self):
        st, pg = self.make()
        attach_switch(st, pg, true_in=0.5)
        st.home()
        again = Stepper(st.cfg, pg)
        self.assertEqual(again.reference, "switch")
        self.assertAlmostEqual(again.position_in, 0.0, delta=0.0005)

    def test_no_switch_configured(self):
        st, _ = self.make(home_pin=None)
        self.assertFalse(st.has_home_switch)
        self.assertIsNone(st.position_info()["home_switch"])
        with self.assertRaises(MotionError):
            st.home()

    def test_switch_never_found(self):
        st, pg = self.make()
        attach_switch(st, pg, true_in=0.1, switch_in=-1000.0)             # switch is nowhere in reach
        with self.assertRaisesRegex(MotionError, "not found"):
            st.home(max_travel_in=0.2)
        self.assertEqual(st.reference, "none")
        self.assertEqual(pg.last.gpio[19], 1)                            # still released after the failure

    def test_switch_stuck_pressed(self):
        st, pg = self.make()
        attach_switch(st, pg, true_in=0.0, switch_in=1000.0)              # always reads pressed
        with self.assertRaisesRegex(MotionError, "still pressed"):
            st.home()
        self.assertEqual(st.reference, "none")

    def test_position_info(self):
        st, _ = self.make(home_pin=None)
        st.set_zero()
        st.move_inches(1.5)
        info = st.position_info()
        self.assertAlmostEqual(info["inches"], 1.5, places=3)
        self.assertAlmostEqual(info["mm"], 38.1, places=1)
        self.assertAlmostEqual(info["fraction_of_tube"], 0.5, places=3)
        self.assertEqual(info["reference"], "manual")
        self.assertFalse(info["uncertain"])
        json.dumps(info)

    def test_manual_zero_sets_reference(self):
        st, _ = self.make(home_pin=None)
        self.assertEqual(st.reference, "none")
        st.set_zero()
        self.assertEqual(st.reference, "manual")


# ----------------------------------------------------------------- calibration
class CalibrationTests(unittest.TestCase):
    def make(self, **kw):
        cal = Path(TMP) / f"cal_{time.monotonic_ns()}.json"
        kw.setdefault("tube_length_in", 17.0)
        st = Stepper(stepper_cfg(calibration_file=str(cal), **kw), FakePigpio(time_scale=2000))
        return st, cal

    def run_keys(self, st, keys, answers=()):
        from hyphalcam.calibrate import run_interactive
        keys, answers, shown = iter(keys), iter(answers), []
        result = run_interactive(st, lambda: next(keys), lambda prompt: next(answers), shown.append)
        return result, "".join(shown)

    def test_full_flow_saves_length_and_applies_it(self):
        st, cal = self.make()
        st._pos_fine = to_fine(st, 3.0)                     # carriage left somewhere random
        result, shown = self.run_keys(st, ["h", "s", "s", "s", "s", "e"], ["", ""])   # 4 x 0.5 in down
        self.assertAlmostEqual(result.tube_length_in, 2.0, places=3)
        self.assertEqual(st.cfg.tube_length_in, result.tube_length_in)
        self.assertAlmostEqual(st.position_in, 0.0, delta=0.001)           # returned home (Enter = yes)
        self.assertEqual(st.reference, "manual")
        data = json.loads(cal.read_text())
        self.assertAlmostEqual(data["tube_length_in"], 2.0, places=3)
        self.assertIn("Saved", shown)
        with self.assertRaises(LimitError):                                # new soft limit is in force
            st.move_inches(2.5)
        st.move_to_inches(result.tube_length_in)                           # but the true end is reachable

    def test_tape_measurement_corrects_pitch(self):
        st, cal = self.make()
        result, _ = self.run_keys(st, ["h", "s", "s", "s", "s", "e"], ["1.9", "n"])
        self.assertTrue(result.corrected_with_tape)
        self.assertAlmostEqual(result.tube_length_in, 1.9)
        self.assertAlmostEqual(result.inches_per_rev, 0.063 * 1.9 / 2.0, places=6)
        self.assertAlmostEqual(st.position_in, 1.9, delta=0.001)           # stayed at the end ("n")
        self.assertEqual(st.cfg.tube_length_in, 1.9)

    def test_mistakes_are_explained_and_calibration_continues(self):
        st, cal = self.make()
        result, shown = self.run_keys(
            st, ["e",                                  # end before home
                 "h", "e",                             # home, but no travel yet
                 "w", "e",                             # moved the wrong way: above home
                 "s", "s", "s", "s", "s", "s", "e",    # then a good run; tape answer "abc" is rejected
                 "e"],                                 # press E again
            ["abc", "", ""])                           # not a number, then Enter (accept), then Enter (go home)
        self.assertIn("Mark home first", shown)
        self.assertIn("only 0.00 in from home", shown)
        self.assertIn("ABOVE the home mark", shown)
        self.assertIn("wasn't a number", shown)
        self.assertIsNotNone(result)

    def test_quit_saves_nothing(self):
        st, cal = self.make()
        result, shown = self.run_keys(st, ["h", "s", "q"])
        self.assertIsNone(result)
        self.assertFalse(cal.exists())
        self.assertEqual(st.cfg.tube_length_in, 17.0)
        self.assertIn("nothing saved", shown)

    def test_step_size_keys(self):
        from hyphalcam.calibrate import CalibrationSession
        st, _ = self.make()
        s = CalibrationSession(st)
        self.assertEqual(s.step_in, 0.5)
        s.bigger(); s.bigger(); s.bigger()
        self.assertEqual(s.step_in, 5.0)                                   # clamps at the largest
        for _ in range(10):
            s.smaller()
        self.assertEqual(s.step_in, 0.005)

    def test_travel_safety_limit(self):
        st, cal = self.make(calibration_max_travel_in=1.0)
        result, shown = self.run_keys(st, ["h", "s", "s", "s", "s", "q"])  # 4 x 0.5 in, limit is 1.0
        self.assertIn("safety limit", shown)
        self.assertAlmostEqual(st.position_in, 1.0, delta=0.001)

    def test_jog_ignores_soft_limits_but_normal_moves_do_not(self):
        st, _ = self.make(tube_length_in=1.0)
        result, _ = self.run_keys(st, ["h", "s", "s", "s", "s", "e"], ["", "n"])   # 2.0 in > 1.0 in limit
        self.assertAlmostEqual(result.tube_length_in, 2.0, places=3)

    def test_apply_calibration_overrides_config(self):
        from hyphalcam.config import apply_calibration
        st, cal = self.make()
        self.run_keys(st, ["h", "s", "s", "s", "s", "e"], ["1.9", "n"])
        cfg = Config()
        cfg.stepper.calibration_file = str(cal)
        self.assertIsNotNone(apply_calibration(cfg))
        self.assertEqual(cfg.stepper.tube_length_in, 1.9)
        self.assertAlmostEqual(cfg.stepper.inches_per_rev, 0.05985, places=6)
        fresh = Stepper(cfg.stepper, FakePigpio(time_scale=2000))
        with self.assertRaises(LimitError):
            fresh.move_inches(1.95)

    def test_apply_calibration_without_or_with_bad_file(self):
        from hyphalcam.config import apply_calibration
        cfg = Config()
        cfg.stepper.calibration_file = str(Path(TMP) / "does_not_exist.json")
        self.assertIsNone(apply_calibration(cfg))
        self.assertEqual(cfg.stepper.tube_length_in, 17.0)
        bad = Path(TMP) / "bad_cal.json"
        bad.write_text("{not json")
        cfg.stepper.calibration_file = str(bad)
        self.assertIsNone(apply_calibration(cfg))
        bad.write_text(json.dumps({"tube_length_in": -3, "inches_per_rev": 0.063}))
        self.assertIsNone(apply_calibration(cfg))
        self.assertEqual(cfg.stepper.tube_length_in, 17.0)

    def test_set_geometry_validation(self):
        st, _ = self.make()
        with self.assertRaises(ValueError):
            st.set_geometry(tube_length_in=0)
        with self.assertRaises(ValueError):
            st.set_geometry(inches_per_rev=-1)


# ----------------------------------------------------------------- LEDs / PCA9685
class LedTests(unittest.TestCase):
    def make(self, **kw):
        bus = FakeI2C()
        pca = PCA9685(i2c=bus, pwm_hz=1500)
        return LedController(pca, **kw), pca, bus

    def regs(self, bus, channel):
        base = LED0_ON_L + 4 * channel
        return list(bus.regs[base: base + 4])

    def test_prescale_values(self):
        self.assertEqual(prescale_for(1500), 3)
        self.assertEqual(prescale_for(1000), 5)
        self.assertEqual(prescale_for(50), 121)          # datasheet example: 50 Hz -> 0x79
        self.assertEqual(prescale_for(1e6), 3)           # clamped to the legal minimum

    def test_init_state(self):
        _, pca, bus = self.make()
        self.assertEqual(bus.regs[PRESCALE], 3)
        self.assertAlmostEqual(pca.actual_hz, 25e6 / (4096 * 4))
        self.assertEqual(bus.regs[0x00] & 0x10, 0)       # awake
        self.assertEqual(bus.regs[0x00] & 0x20, 0x20)    # auto-increment on
        self.assertEqual(bus.regs[0x00] & 0x01, 0)       # all-call off (shared bus)
        self.assertEqual(bus.regs[0x01] & 0x04, 0x04)    # totem-pole

    def test_everything_off_at_start(self):
        _, _, bus = self.make()
        for ch in range(16):
            self.assertEqual(self.regs(bus, ch)[3] & FULL, FULL, ch)

    def test_register_encoding(self):
        self.assertEqual(channel_registers(0), [0, 0, 0, FULL])
        self.assertEqual(channel_registers(4096), [0, FULL, 0, 0])
        self.assertEqual(channel_registers(2048, 0), [0, 0, 0, 8])
        self.assertEqual(channel_registers(2048, 3584), [0, 14, 0, 6])   # wraps past 4096

    def test_full_brightness_uses_full_on_bit(self):
        leds, _, bus = self.make()
        leds.set("white", 1.0)
        self.assertEqual(self.regs(bus, 8), [0, FULL, 0, 0])
        self.assertEqual(leds.state()["white"], 1.0)

    def test_half_brightness_pwm_with_stagger(self):
        leds, _, bus = self.make()
        leds.set("white", 0.5)                            # white is channel 8 -> phase 8*256 = 2048
        on = bus.regs[LED0_ON_L + 32] + 256 * bus.regs[LED0_ON_L + 33]
        off = bus.regs[LED0_ON_L + 34] + 256 * bus.regs[LED0_ON_L + 35]
        self.assertEqual(on, 2048)
        self.assertEqual((off - on) % 4096, 2048)

    def test_gamma_and_clamp(self):
        leds, _, bus = self.make(gamma=2.0)
        leds.set("red", 0.5)                              # 0.25 * 4096 = 1024 on-counts
        on = bus.regs[LED0_ON_L + 36] + 256 * bus.regs[LED0_ON_L + 37]
        off = bus.regs[LED0_ON_L + 38] + 256 * bus.regs[LED0_ON_L + 39]
        self.assertEqual((off - on) % 4096, 1024)
        leds.set("red", 7.0)
        self.assertEqual(leds.state()["red"], 1.0)
        leds.set("red", -3)
        self.assertEqual(leds.state()["red"], 0.0)

    def test_unknown_led_and_unchanged_others(self):
        leds, _, _ = self.make()
        with self.assertRaises(KeyError):
            leds.set("purple", 1)
        leds.set("green", 0.4)
        leds.set("amber", 0.2)
        self.assertEqual(leds.state()["green"], 0.4)

    def test_set_many_and_all_off_and_block_size(self):
        leds, _, bus = self.make()
        bus.writes.clear()
        leds.set_many({"uv_365": 1.0, "nir_a": 1.0})
        self.assertEqual(len(bus.writes), 2)                      # two 32-byte block writes
        self.assertTrue(all(len(d) <= 32 for _, d in bus.writes))
        self.assertEqual(self.regs(bus, 15), [0, FULL, 0, 0])
        self.assertEqual(self.regs(bus, 7), [0, FULL, 0, 0])
        leds.all_off()
        for ch in range(16):
            self.assertEqual(self.regs(bus, ch)[3] & FULL, FULL)
        self.assertTrue(all(v == 0 for v in leds.state().values()))

    def test_illuminate_context_turns_off_even_on_error(self):
        leds, _, bus = self.make()
        with self.assertRaises(RuntimeError):
            with leds.illuminate({"white": 1.0}):
                self.assertEqual(leds.state()["white"], 1.0)
                raise RuntimeError("boom")
        self.assertEqual(leds.state()["white"], 0.0)
        self.assertEqual(self.regs(bus, 8)[3] & FULL, FULL)

    def test_max_level_and_total_cap(self):
        chans = [type(c)(**{**c.__dict__}) for c in DEFAULT_LEDS]
        chans[0].max_level = 0.5
        leds, _, _ = self.make(channels=chans, max_total_level=1.5)
        leds.set("uv_365", 1.0)
        self.assertEqual(leds.state()["uv_365"], 0.5)
        leds.set_many({"white": 1.0, "green": 1.0})
        self.assertAlmostEqual(sum(leds.state().values()), 1.5)

    def test_describe_is_ui_ready(self):
        leds, _, _ = self.make()
        d = {x["name"]: x for x in leds.describe()}
        self.assertEqual(len(d), 10)
        self.assertEqual(d["uv_365"]["channel"], 15)
        self.assertEqual(d["nir_b"]["channel"], 6)
        json.dumps(list(d.values()))                      # must serialise for a web UI

    def test_duplicate_channels_rejected(self):
        a, b = DEFAULT_LEDS[0], DEFAULT_LEDS[1]
        bad = [a, type(b)(**{**b.__dict__, "channel": a.channel})]
        with self.assertRaises(ValueError):
            self.make(channels=bad)


# ----------------------------------------------------------------- camera
class CameraTests(unittest.TestCase):
    def setUp(self):
        self.fake = FakePicamera2()
        self.limits = self.fake.camera_controls

    def test_iso_and_exposure_translate(self):
        out = translate_settings({"iso": 400, "exposure_us": 50_000}, self.limits)
        self.assertEqual(out["AnalogueGain"], 4.0)
        self.assertEqual(out["ExposureTime"], 50_000)
        self.assertFalse(out["AeEnable"])
        self.assertEqual(out["FrameDurationLimits"], (50_000, 50_000))

    def test_long_exposure_stretches_frame_duration(self):
        out = translate_settings({"exposure_us": 2_000_000}, self.limits)
        self.assertEqual(out["FrameDurationLimits"], (2_000_000, 2_000_000))

    def test_auto_exposure_ignores_manual_values(self):
        out = translate_settings({"auto_exposure": True, "iso": 800}, self.limits)
        self.assertTrue(out["AeEnable"])
        self.assertNotIn("AnalogueGain", out)

    def test_clamping(self):
        out = translate_settings({"iso": 100_000, "exposure_us": 10 ** 12}, self.limits)
        self.assertEqual(out["AnalogueGain"], 22.26)
        self.assertEqual(out["ExposureTime"], 200_000_000)

    def test_errors_and_colour_gains(self):
        with self.assertRaises(ValueError):
            translate_settings({"isoo": 100}, self.limits)
        with self.assertRaises(ValueError):
            translate_settings({"iso": 100, "analogue_gain": 1.0}, self.limits)
        out = translate_settings({"colour_gains": (1.5, 1.8)}, self.limits)
        self.assertEqual(out["ColourGains"], (1.5, 1.8))
        self.assertFalse(out["AwbEnable"])

    def test_unsupported_control_is_skipped(self):
        del self.limits["Sharpness"]
        out = translate_settings({"sharpness": 4.0}, self.limits)
        self.assertNotIn("Sharpness", out)
        out = translate_settings({"lens_position": 2.0}, self.limits)      # HQ camera has no focus motor
        self.assertNotIn("LensPosition", out)

    def test_apply_waits_for_sensor_and_capture_writes_files(self):
        cam = CameraController(CameraConfig(format="both", settings={}), self.fake)
        cam.start()
        cam.apply(iso=200, exposure_us=12_000)
        self.assertEqual(self.fake._applied["ExposureTime"], 12_000)        # wait_applied really waited
        self.assertEqual(self.fake._applied["AnalogueGain"], 2.0)
        files, md = cam.capture(Path(TMP) / "shot")
        self.assertEqual(sorted(f.suffix for f in files), [".dng", ".jpg"])
        self.assertTrue(all(f.exists() for f in files))
        self.assertEqual(md["ExposureTime"], 12_000)
        self.assertEqual(self.fake.released, 1)
        self.assertEqual(self.fake.options["quality"], 95)

    def test_describe_for_sliders(self):
        cam = CameraController(CameraConfig(settings={}), self.fake)
        cam.start()
        cam.apply(iso=300)
        d = cam.describe()
        self.assertEqual(d["iso"]["min"], 100.0)
        self.assertAlmostEqual(d["iso"]["max"], 2226.0)
        self.assertEqual(d["iso"]["value"], 300)
        self.assertNotIn("lens_position", d)


# ----------------------------------------------------------------- scan, end to end
class ScanTests(unittest.TestCase):
    def build(self, upload_ok=True, stepper_kw=None, scale=500, **scan_kw):
        cfg = Config()
        cfg.stepper = stepper_cfg(tube_length_in=0.5, max_rpm=600, **(stepper_kw or {}))
        cfg.scan.num_positions = 3
        cfg.scan.settle_after_move_s = 0.0
        cfg.scan.staging_dir = str(Path(TMP) / f"stage_{time.monotonic_ns()}")
        cfg.scan.presets = [Preset("white", {"white": 1.0}, {"iso": 100, "exposure_us": 8000}, 0.0),
                            Preset("uv", {"uv_365": 1.0}, {"iso": 400, "exposure_us": 100_000}, 0.0)]
        cfg.camera.settings = {}
        for k, v in scan_kw.items():
            setattr(cfg.scan, k, v)
        pg = FakePigpio(time_scale=scale)
        stepper = Stepper(cfg.stepper, pg)
        bus = FakeI2C()
        leds = LedController.from_config(cfg.leds, PCA9685(i2c=bus))
        cam = CameraController(cfg.camera, FakePicamera2())
        cam.start()
        calls = []

        def uploader(src, remote, folder, retries, wait):
            calls.append((Path(src), remote, folder, sorted(p.name for p in Path(src).iterdir())))
            return upload_ok
        return cfg, ScanRunner(cfg, stepper, leds, cam, uploader), stepper, leds, bus, calls, pg

    def test_full_scan(self):
        cfg, runner, stepper, leds, bus, calls, pg = self.build()
        res = runner.run()
        self.assertTrue(res.completed and res.uploaded)
        self.assertEqual(len(res.files), 6)                              # 3 positions x 2 presets
        self.assertAlmostEqual(stepper.position_in, 0.0, delta=0.0002)   # returned home
        self.assertTrue(all(v == 0 for v in leds.state().values()))      # LEDs off
        self.assertEqual(pg.last.gpio[19], 1)                            # motor released
        src, remote, folder, names = calls[0]
        self.assertEqual(remote, "guzmanpi1_gdrive")
        self.assertRegex(folder, r"^rpicamfiles/\d{4}-\d\d-\d\d/camera1/run_\d\d-\d\d$")
        self.assertIn("manifest.json", names)
        self.assertEqual(sum(n.endswith(".jpg") for n in names), 6)
        self.assertTrue(any(n.startswith("pos2_of3__uv__") for n in names))
        self.assertFalse(src.exists())                                    # cleaned up after success

    def test_manifest_contents(self):
        cfg, runner, stepper, *_ = self.build(upload_ok=False)
        res = runner.run()
        m = json.loads((res.folder / "manifest.json").read_text())
        self.assertEqual(len(m["images"]), 6)
        first = m["images"][0]
        self.assertEqual(first["preset"], "white")
        self.assertAlmostEqual(first["position_in"], 0.5 / 3, delta=0.001)
        self.assertEqual(first["metadata"]["ExposureTime"], 8000)

    def test_failed_upload_keeps_photos(self):
        cfg, runner, *_ = self.build(upload_ok=False)
        res = runner.run()
        self.assertFalse(res.uploaded)
        self.assertTrue(res.folder.exists())
        self.assertEqual(len(list(res.folder.glob("*.jpg"))), 6)

    def test_cancel_still_cleans_up_and_uploads_partial(self):
        cfg, runner, stepper, leds, bus, calls, pg = self.build()
        orig = runner.camera.capture
        count = {"n": 0}

        def capture_then_cancel(stem):
            out = orig(stem)
            count["n"] += 1
            if count["n"] == 3:
                runner.cancel()
            return out
        runner.camera.capture = capture_then_cancel
        res = runner.run()
        self.assertFalse(res.completed)
        self.assertEqual(len(res.files), 3)
        self.assertTrue(all(v == 0 for v in leds.state().values()))
        self.assertEqual(len(calls), 1)                                  # partial set still uploaded

    def test_error_midway_turns_leds_off(self):
        cfg, runner, stepper, leds, *_ = self.build()
        def boom(stem): raise OSError("disk full")
        runner.camera.capture = boom
        with self.assertRaises(OSError):
            runner.run()
        self.assertTrue(all(v == 0 for v in leds.state().values()))

    def test_refuses_when_position_uncertain(self):
        cfg, runner, stepper, *_ = self.build()
        stepper.position_uncertain = True
        with self.assertRaises(PositionUncertain):
            runner.run()
        self.assertTrue(runner.run(force=True).completed)

    def test_scan_auto_homes_when_position_uncertain(self):
        cfg, runner, stepper, leds, bus, calls, pg = self.build(
            upload_ok=False, scale=10, stepper_kw={"home_pin": 17})
        attach_switch(stepper, pg, true_in=0.2)                  # real position 0.2 in...
        stepper._pos_fine = 0                                     # ...but software thinks 0
        stepper.position_uncertain = True
        res = runner.run()                                        # would raise without a switch
        self.assertTrue(res.completed)
        self.assertEqual(stepper.reference, "switch")
        m = json.loads((res.folder / "manifest.json").read_text())
        self.assertEqual(m["images"][0]["position_reference"], "switch")
        self.assertAlmostEqual(m["images"][0]["position_in"], 0.5 / 3, delta=0.002)
        self.assertAlmostEqual(m["images"][0]["position_mm"], 0.5 / 3 * 25.4, delta=0.05)

    def test_scan_skips_homing_when_disabled(self):
        cfg, runner, stepper, *_ = self.build(scale=10, stepper_kw={"home_pin": 17}, home_before_scan=False)
        attach_switch(stepper, runner.stepper.pi and self.pg_of(stepper), true_in=0.0)
        res = runner.run()
        self.assertTrue(res.completed)
        self.assertEqual(stepper.reference, "none")

    @staticmethod
    def pg_of(stepper):
        class _H:      # attach_switch only needs `.last`
            last = stepper.pi
        return _H

    def test_starts_from_zero_even_if_left_extended(self):
        cfg, runner, stepper, *_ = self.build()
        stepper.move_inches(0.2)
        res = runner.run()
        self.assertTrue(res.completed)
        self.assertAlmostEqual(stepper.position_in, 0.0, delta=0.0002)


# ----------------------------------------------------------------- config
class ConfigTests(unittest.TestCase):
    def test_example_toml_loads_and_matches_defaults(self):
        cfg = load_config(Path(__file__).resolve().parent.parent / "hyphalcam.example.toml")
        self.assertEqual(cfg.stepper.microstep, 16)
        self.assertEqual(cfg.scan.presets[0].name, "white")
        self.assertEqual(cfg.scan.presets[0].camera["iso"], 100)
        self.assertEqual(cfg.scan.upload.base_folder, "rpicamfiles")
        self.assertEqual(cfg.camera.settings, {"auto_exposure": True})

    def test_typos_are_rejected(self):
        p = Path(TMP) / "bad.toml"
        p.write_text("[stepper]\nmicrostepp = 8\n")
        with self.assertRaises(ValueError):
            load_config(p)

    def test_custom_led_channels(self):
        p = Path(TMP) / "leds.toml"
        p.write_text('[[leds.channels]]\nname = "x"\nchannel = 0\n')
        self.assertEqual(load_config(p).leds.channels[0].name, "x")


if __name__ == "__main__":
    unittest.main()
