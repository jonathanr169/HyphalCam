*PADS-LIBRARY-PART-TYPES-V9*

LTPL-C034UVH365 LTPLC034UVH365 I DIO 7 1 0 0 0
TIMESTAMP 2026.08.12.18.49.05
"Mouser Part Number" 859-LTPL-C034UVH365
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/LITEON/LTPL-C034UVH365?qs=pPiH5vUCJeR2s22VxlBhsw%3D%3D
"Manufacturer_Name" Lite-On
"Manufacturer_Part_Number" LTPL-C034UVH365
"Description" High Power LEDs - Single Color HIGH PWR UV 365nm
"Datasheet Link" https://optoelectronics.liteon.com/upload/download/DS23-2015-0072/LTPL-C034UVH365%20DataSheet.PDF
"Geometry.Height" 2mm
GATE 1 3 0
LTPL-C034UVH365
1 0 U K
2 0 U A
3 0 U THERMAL_PAD_(ND)

*END*
*REMARK* SamacSys ECAD Model
688317/2126859/2.50/3/4/LED
