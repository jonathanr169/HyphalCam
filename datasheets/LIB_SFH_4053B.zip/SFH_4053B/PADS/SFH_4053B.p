*PADS-LIBRARY-PART-TYPES-V9*

SFH_4053B SFH4053B I DIO 7 1 0 0 0
TIMESTAMP 2026.08.12.18.02.27
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" ams OSRAM
"Manufacturer_Part_Number" SFH 4053B
"Description" Infrared Emitters IR LED THIN-FILM CHIP 850NM 70 mA,52 mW,-40 C+85 C,1.0 mm x 0.5 mm x 0.45 mm
"Datasheet Link" https://look.ams-osram.com/m/55e7e2841f6c672c/original/SFH-4053B.pdf
"Geometry.Height" 0.55mm
GATE 1 2 0
SFH_4053B
2 0 U K
1 0 U A

*END*
*REMARK* SamacSys ECAD Model
21948620/2126859/2.50/2/3/LED
