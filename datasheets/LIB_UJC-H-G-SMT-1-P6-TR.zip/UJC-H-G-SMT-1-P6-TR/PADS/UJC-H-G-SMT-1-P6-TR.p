*PADS-LIBRARY-PART-TYPES-V9*

UJC-H-G-SMT-1-P6-TR UJCHGSMT1P6TR I CON 7 1 0 0 0
TIMESTAMP 2026.11.14.18.36.27
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" Same Sky
"Manufacturer_Part_Number" UJC-H-G-SMT-1-P6-TR
"Description" UJC-H-G-SMT-1-P6-TR - Type C, Power Only, 5 Vdc, 5 A, Vertical, Surface Mount w/ Anchor Pins, SMT Contacts, Gold Flash, 6 Pins, USB Receptacle
"Datasheet Link" https://www.sameskydevices.com/product/resource/ujc-h-g-smt-1-p6-tr.pdf
"Geometry.Height" 3.36mm
GATE 1 10 0
UJC-H-G-SMT-1-P6-TR
A5 0 U CC1
A9 0 U VBUS_1
A12 0 U GND_1
B5 0 U CC2
B9 0 U VBUS_2
B12 0 U GND_2
MH1 0 U MH1
MH2 0 U MH2
MH3 0 U MH3
MH4 0 U MH4

*END*
*REMARK* SamacSys ECAD Model
21454278/2126859/2.50/10/2/Connector
