*PADS-LIBRARY-PART-TYPES-V9*

L1SP-DRD0203E00000 L1SPDRD0203E00000 I DIO 7 1 0 0 0
TIMESTAMP 2026.08.07.22.06.28
"Mouser Part Number" 997-L1SPDRD0203E00
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Lumileds/L1SP-DRD0203E00000?qs=Znm5pLBrcAJJHSEisLNI6Q%3D%3D
"Manufacturer_Name" Lumileds
"Manufacturer_Part_Number" L1SP-DRD0203E00000
"Description" High Power LEDs - Single Color Deep Red 655nm-680nm LUXEON SunPlus HPE
"Datasheet Link" https://lumileds.com/wp-content/uploads/2022/04/DS416-luxeon-sunplus-hpe-datasheet.pdf
"Geometry.Height" 2.415mm
GATE 1 3 0
L1SP-DRD0203E00000
1 0 U K_1
2 0 U A
3 0 U K_2

*END*
*REMARK* SamacSys ECAD Model
16283840/2126859/2.50/3/3/LED
