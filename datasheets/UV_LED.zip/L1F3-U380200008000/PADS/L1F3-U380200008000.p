*PADS-LIBRARY-PART-TYPES-V9*

L1F3-U380200008000 L1F3U380200008000 I DIO 7 1 0 0 0
TIMESTAMP 2026.08.07.00.15.04
"Mouser Part Number" 997-L1F3U3802008000
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Lumileds/L1F3-U380200008000?qs=HXFqYaX1Q2zmp533hKZ8tw%3D%3D
"Manufacturer_Name" Lumileds
"Manufacturer_Part_Number" L1F3-U380200008000
"Description" High Power LEDs - Single Color UV/NUV
"Datasheet Link" https://lumileds.com/wp-content/uploads/files/DS178.pdf
"Geometry.Height" 0.76mm
GATE 1 2 0
L1F3-U380200008000
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
877921/2126859/2.50/2/3/LED
