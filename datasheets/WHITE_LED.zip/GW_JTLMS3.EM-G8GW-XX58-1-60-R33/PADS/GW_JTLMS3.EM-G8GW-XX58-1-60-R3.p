*PADS-LIBRARY-PART-TYPES-V9*

GW_JTLMS3.EM-G8GW-XX58-1-60-R3 GWJTLMS3EMG8GWXX58160R33 I DIO 7 1 0 0 0
TIMESTAMP 2026.08.07.00.25.17
"Mouser Part Number" 720-GWJTLMS3.E8GW58
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/ams-OSRAM/GW-JTLMS3.EM-G8GW-XX58-1-60-R33?qs=wT7LY0lnAe18jblHP2yyfQ%3D%3D
"Manufacturer_Name" ams OSRAM
"Manufacturer_Part_Number" GW JTLMS3.EM-G8GW-XX58-1-60-R33
"Description" LED Lighting DURIS E 2835 White, Warm 2700K 3.15V 60mA 120 2-SMD, No Lead
"Datasheet Link" https://look.ams-osram.com/m/4acf99575c8ce45/original/GW-JTLMS3-EM.pdf
"Geometry.Height" 0.73mm
GATE 1 4 0
GW_JTLMS3.EM-G8GW-XX58-1-60-R3
1 0 U K_1
2 0 U A_1
3 0 U K_2
4 0 U A_2

*END*
*REMARK* SamacSys ECAD Model
20099225/2126859/2.50/4/4/LED
